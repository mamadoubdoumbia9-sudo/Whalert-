# Android default proguard rules
-keep class androidx.** { *; }
-keep class com.google.** { *; }
-keep class android.** { *; }

# Keep all activities
-keep public class * extends androidx.appcompat.app.AppCompatActivity
-keep public class * extends androidx.activity.ComponentActivity

# Keep all viewmodels
-keep public class * extends androidx.lifecycle.ViewModel

# Keep Compose functions
-keep class androidx.compose.runtime.** { *; }
-keep class androidx.compose.ui.** { *; }
-keep class androidx.compose.material3.** { *; }

# Keep Room database classes
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.Database
-keep class * extends androidx.room.Entity
-keep class * extends androidx.room.Dao

# Keep Retrofit and OkHttp
-keep class retrofit2.** { *; }
-keep class okhttp3.** { *; }
-keep class com.squareup.okhttp.** { *; }
-keep interface retrofit2.** { *; }

# Keep Gson
-keep class com.google.gson.** { *; }
-keep class com.google.gson.reflect.TypeToken

# Keep Firebase
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# Keep phone number library
-keep class com.google.i18n.phonenumbers.** { *; }

# Keep Coil
-keep class coil.** { *; }

# Keep data classes for Room and Gson
-keepclassmembers class * {
    @androidx.room.Entity <methods>;
}
-keepclassmembers class * {
    @androidx.room.Dao <methods>;
}
-keepclassmembers class * {
    @androidx.room.Database <methods>;
}

# Keep R classes
-keep class **.R$* { *; }

# Keep Kotlin metadata
-keep class kotlin.Metadata { *; }
-keep class kotlin.** { *; }

# Keep coroutines
-keep class kotlinx.coroutines.** { *; }

# Keep parcelable classes
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Keep for serialization
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private <fields>;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
}

# Remove logging calls in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# Optimizations
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontpreverify
-verbose

# Keep all classes in the application package
-keep class com.whalert.app.** { *; }

# Keep all enum values
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
