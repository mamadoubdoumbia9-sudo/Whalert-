package com.whalert.app

import android.app.Application
import android.content.Context
import androidx.datastore.core.DataStore
nimport androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.whalert.app.di.appModule
import com.whalert.app.di.dataModule
import com.whalert.app.di.domainModule
import com.whalert.app.di.presentationModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.logger.Level

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "whalert_prefs")

class WhAlertApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize Koin for dependency injection
        startKoin {
            androidLogger(Level.ERROR)
            androidContext(this@WhAlertApplication)
            modules(
                appModule,
                dataModule,
                domainModule,
                presentationModule
            )
        }
        
        // Initialize app settings
        AppSettings.init(this)
    }
}

object AppSettings {
    private lateinit var context: Context
    
    fun init(appContext: Context) {
        context = appContext
    }
    
    fun getContext(): Context = context
}
