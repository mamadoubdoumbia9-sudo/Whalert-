package com.whalert.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.whalert.app.data.local.converter.Converters
import com.whalert.app.data.local.entity.ReportEntity
import com.whalert.app.data.local.entity.UserEntity

@Database(
    entities = [
        ReportEntity::class,
        UserEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    
    abstract fun reportDao(): ReportDao
    abstract fun userDao(): UserDao
}
