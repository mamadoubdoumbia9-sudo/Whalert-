package com.whalert.app.data.local

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.whalert.app.util.Constants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class UserPreferencesRepository(private val dataStore: DataStore<Preferences>) {
    
    companion object {
        private val THEME_PREF = stringPreferencesKey(Constants.PREF_THEME)
        private val LANGUAGE_PREF = stringPreferencesKey(Constants.PREF_LANGUAGE)
        private val NOTIFICATIONS_ENABLED = booleanPreferencesKey(Constants.PREF_NOTIFICATIONS_ENABLED)
        private val NOTIFICATIONS_SOUND = booleanPreferencesKey(Constants.PREF_NOTIFICATIONS_SOUND)
        private val NOTIFICATIONS_VIBRATE = booleanPreferencesKey(Constants.PREF_NOTIFICATIONS_VIBRATE)
        private val BIOMETRIC_ENABLED = booleanPreferencesKey(Constants.PREF_BIOMETRIC_ENABLED)
        private val DAILY_LIMIT = stringPreferencesKey(Constants.PREF_DAILY_LIMIT)
        private val FIRST_LAUNCH = booleanPreferencesKey(Constants.PREF_FIRST_LAUNCH)
        private val ONBOARDING_COMPLETED = booleanPreferencesKey(Constants.PREF_ONBOARDING_COMPLETED)
    }
    
    // Theme
    val themeFlow: Flow<String> = dataStore.data.map { preferences ->
        preferences[THEME_PREF] ?: Constants.THEME_SYSTEM
    }
    
    suspend fun setTheme(theme: String) {
        dataStore.edit { preferences ->
            preferences[THEME_PREF] = theme
        }
    }
    
    // Language
    val languageFlow: Flow<String> = dataStore.data.map { preferences ->
        preferences[LANGUAGE_PREF] ?: Constants.LANGUAGE_SYSTEM
    }
    
    suspend fun setLanguage(language: String) {
        dataStore.edit { preferences ->
            preferences[LANGUAGE_PREF] = language
        }
    }
    
    // Notifications
    val notificationsEnabledFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[NOTIFICATIONS_ENABLED] ?: true
    }
    
    suspend fun setNotificationsEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[NOTIFICATIONS_ENABLED] = enabled
        }
    }
    
    val notificationsSoundFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[NOTIFICATIONS_SOUND] ?: true
    }
    
    suspend fun setNotificationsSound(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[NOTIFICATIONS_SOUND] = enabled
        }
    }
    
    val notificationsVibrateFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[NOTIFICATIONS_VIBRATE] ?: true
    }
    
    suspend fun setNotificationsVibrate(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[NOTIFICATIONS_VIBRATE] = enabled
        }
    }
    
    // Biometric
    val biometricEnabledFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[BIOMETRIC_ENABLED] ?: false
    }
    
    suspend fun setBiometricEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[BIOMETRIC_ENABLED] = enabled
        }
    }
    
    // Daily Limit
    val dailyLimitFlow: Flow<String> = dataStore.data.map { preferences ->
        preferences[DAILY_LIMIT] ?: "3"
    }
    
    suspend fun setDailyLimit(limit: String) {
        dataStore.edit { preferences ->
            preferences[DAILY_LIMIT] = limit
        }
    }
    
    // First Launch
    val firstLaunchFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[FIRST_LAUNCH] ?: true
    }
    
    suspend fun setFirstLaunchCompleted() {
        dataStore.edit { preferences ->
            preferences[FIRST_LAUNCH] = false
        }
    }
    
    // Onboarding
    val onboardingCompletedFlow: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[ONBOARDING_COMPLETED] ?: false
    }
    
    suspend fun setOnboardingCompleted() {
        dataStore.edit { preferences ->
            preferences[ONBOARDING_COMPLETED] = true
        }
    }
    
    // Clear all preferences
    suspend fun clearAll() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
