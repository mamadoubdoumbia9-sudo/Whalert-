package com.whalert.app.data.local.converter

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.model.ReportStatus
import java.lang.reflect.Type
import java.util.Date

class Converters {
    
    private val gson = Gson()
    
    @TypeConverter
    fun fromReportCategory(category: ReportCategory): String {
        return category.name
    }
    
    @TypeConverter
    fun toReportCategory(value: String): ReportCategory {
        return ReportCategory.valueOf(value)
    }
    
    @TypeConverter
    fun fromReportStatus(status: ReportStatus): String {
        return status.name
    }
    
    @TypeConverter
    fun toReportStatus(value: String): ReportStatus {
        return ReportStatus.valueOf(value)
    }
    
    @TypeConverter
    fun fromDate(date: Date?): Long? {
        return date?.time
    }
    
    @TypeConverter
    fun toDate(value: Long?): Date? {
        return value?.let { Date(it) }
    }
    
    @TypeConverter
    fun fromStringList(list: List<String>?): String? {
        return list?.let { gson.toJson(it) }
    }
    
    @TypeConverter
    fun toStringList(value: String?): List<String>? {
        if (value == null) return null
        val type: Type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, type)
    }
    
    @TypeConverter
    fun fromEvidenceList(list: List<ByteArray>?): String? {
        // Convert byte arrays to Base64 strings
        return list?.map { android.util.Base64.encodeToString(it, android.util.Base64.DEFAULT) }?.let { gson.toJson(it) }
    }
    
    @TypeConverter
    fun toEvidenceList(value: String?): List<ByteArray>? {
        if (value == null) return null
        val type: Type = object : TypeToken<List<String>>() {}.type
        val base64List = gson.fromJson<List<String>>(value, type) ?: return null
        return base64List.map { android.util.Base64.decode(it, android.util.Base64.DEFAULT) }
    }
}
