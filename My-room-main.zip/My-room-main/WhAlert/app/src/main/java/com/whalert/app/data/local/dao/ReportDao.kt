package com.whalert.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.whalert.app.data.local.entity.ReportEntity
import com.whalert.app.domain.model.ReportStatus
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface ReportDao {
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity): Long
    
    @Update
    suspend fun updateReport(report: ReportEntity): Int
    
    @Query("DELETE FROM reports WHERE id = :reportId")
    suspend fun deleteReport(reportId: String): Int
    
    @Query("SELECT * FROM reports WHERE id = :reportId")
    suspend fun getReportById(reportId: String): ReportEntity?
    
    @Query("SELECT * FROM reports ORDER BY createdAt DESC")
    fun getAllReports(): Flow<List<ReportEntity>>
    
    @Query("SELECT * FROM reports WHERE userId = :userId ORDER BY createdAt DESC")
    fun getReportsByUser(userId: String): Flow<List<ReportEntity>>
    
    @Query("SELECT * FROM reports WHERE status = :status ORDER BY createdAt DESC")
    fun getReportsByStatus(status: ReportStatus): Flow<List<ReportEntity>>
    
    @Query("SELECT COUNT(*) FROM reports WHERE userId = :userId AND createdAt >= :startDate")
    suspend fun getDailyReportCount(userId: String, startDate: Date): Int
    
    @Query("SELECT * FROM reports WHERE createdAt >= :startDate AND createdAt <= :endDate ORDER BY createdAt DESC")
    fun getReportsInDateRange(startDate: Date, endDate: Date): Flow<List<ReportEntity>>
    
    @Query("SELECT * FROM reports WHERE phoneNumber LIKE :query OR description LIKE :query ORDER BY createdAt DESC")
    fun searchReports(query: String): Flow<List<ReportEntity>>
    
    @Query("SELECT COUNT(*) FROM reports")
    suspend fun getTotalReportCount(): Int
}
