package com.whalert.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.whalert.app.data.local.converter.Converters
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.model.ReportStatus
import java.util.Date

@Entity(tableName = "reports")
@TypeConverters(Converters::class)
data class ReportEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val phoneNumber: String,
    val countryCode: String,
    val category: ReportCategory,
    val description: String,
    val date: Date? = null,
    val time: String? = null,
    val evidenceText: List<String>? = null,
    val evidenceImages: List<ByteArray>? = null,
    val status: ReportStatus = ReportStatus.DRAFT,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date(),
    val submittedAt: Date? = null,
    val confirmationReceived: Boolean = false,
    val confirmationDetails: String? = null,
    val officialDecision: String? = null
)
