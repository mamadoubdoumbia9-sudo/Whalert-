package com.whalert.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.whalert.app.data.local.converter.Converters
import java.util.Date

@Entity(tableName = "users")
@TypeConverters(Converters::class)
data class UserEntity(
    @PrimaryKey
    val id: String,
    val email: String,
    val displayName: String? = null,
    val phoneNumber: String? = null,
    val avatarUrl: String? = null,
    val isAdmin: Boolean = false,
    val isEmailVerified: Boolean = false,
    val dailyReportLimit: Int = 3,
    val lastReportDate: Date? = null,
    val reportCountToday: Int = 0,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
)
