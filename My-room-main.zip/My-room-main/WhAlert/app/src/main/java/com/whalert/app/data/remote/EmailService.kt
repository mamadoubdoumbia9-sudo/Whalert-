package com.whalert.app.data.remote

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.whalert.app.domain.model.Report
import com.whalert.app.util.Constants

/**
 * Service for sending report emails through official Android intents.
 * This does not use any private APIs or simulate email sending.
 * It uses the device's default email client.
 */
class EmailService(private val context: Context) {
    
    fun sendReportEmail(report: Report, email: String): Boolean {
        val intent = createEmailIntent(report, email)
        
        // Check if there's an email client available
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(Intent.createChooser(intent, "Send Report via Email"))
            return true
        }
        return false
    }
    
    private fun createEmailIntent(report: Report, email: String): Intent {
        val subject = "WhatsApp Report: ${report.category.getDisplayName()} - ${report.getFullPhoneNumber()}"
        val body = buildEmailBody(report)
        
        return Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$email")
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
        }
    }
    
    private fun buildEmailBody(report: Report): String {
        return """
            WhatsApp Account Report
            
            Report ID: ${report.id}
            Submitted: ${report.createdAt}
            
            Reported Account:
            Phone Number: ${report.getFullPhoneNumber()}
            
            Category: ${report.category.getDisplayName()}
            
            Description:
            ${report.description}
            
            Date of Incident: ${report.getFormattedDate()}
            Time of Incident: ${report.getFormattedTime()}
            
            Evidence:
            ${if (report.hasEvidence()) {
                report.evidenceText?.joinToString("\n") { "- Text: $it" } + "\n" +
                report.evidenceImagePaths?.joinToString("\n") { "- Image: $it" }
            } else {
                "No evidence provided"
            }}
            
            ${Constants.EMAIL_SIGNATURE}
        """.trimIndent()
    }
    
    fun openOfficialWhatsAppReport(phoneNumber: String): Boolean {
        // This opens the official WhatsApp reporting mechanism
        // Note: WhatsApp reporting must be done through the official app
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://wa.me/$phoneNumber")
            setPackage("com.whatsapp")
        }
        
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            return true
        }
        return false
    }
    
    fun openWhatsAppHelpCenter() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(Constants.WHATSAPP_HELP_CENTER)
        }
        context.startActivity(intent)
    }
    
    fun openWhatsAppReportGuide() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(Constants.WHATSAPP_REPORT_GUIDE)
        }
        context.startActivity(intent)
    }
}
