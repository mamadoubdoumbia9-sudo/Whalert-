package com.whalert.app.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Service for interacting with official WhatsApp APIs and endpoints.
 * Note: This service only uses publicly available and officially documented endpoints.
 * No private APIs or reverse-engineered endpoints are used.
 */
interface WhatsAppApiService {
    
    companion object {
        const val WHATSAPP_HELP_CENTER = "https://help.whatsapp.com"
        const val WHATSAPP_REPORT_GUIDE = "https://faq.whatsapp.com/general/security-and-privacy/report-a-contact"
        const val WHATSAPP_TERMS = "https://www.whatsapp.com/legal/terms-of-service"
        const val WHATSAPP_PRIVACY = "https://www.whatsapp.com/legal/privacy-policy"
    }
    
    /**
     * Get information about WhatsApp's official reporting procedures.
     * This is a placeholder as WhatsApp does not provide a public API for this.
     * In practice, this would redirect to the official WhatsApp help pages.
     */
    @GET("help/report")
    suspend fun getReportingInfo(): Response<WhatsAppReportInfo>
    
    /**
     * Check if a phone number is valid (format only, not WhatsApp account verification).
     * This uses a validation service that only checks the E.164 format.
     */
    @POST("validate/phone")
    suspend fun validatePhoneNumber(
        @Body request: PhoneValidationRequest
    ): Response<PhoneValidationResponse>
    
    /**
     * Get the official WhatsApp reporting URL for a specific phone number.
     * This generates the official WhatsApp URL that users would use to report.
     */
    @GET("report/url")
    suspend fun getReportUrl(
        @Query("phone") phoneNumber: String,
        @Query("country_code") countryCode: String
    ): Response<ReportUrlResponse>
}

data class WhatsAppReportInfo(
    val reportingUrl: String,
    val procedures: List<String>,
    val categories: List<String>,
    val disclaimer: String
)

data class PhoneValidationRequest(
    val phoneNumber: String,
    val countryCode: String
)

data class PhoneValidationResponse(
    val isValid: Boolean,
    val formattedNumber: String?,
    val error: String?
)

data class ReportUrlResponse(
    val url: String,
    val message: String
)
