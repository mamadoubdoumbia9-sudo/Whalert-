package com.whalert.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.whalert.app.data.local.entity.UserEntity
import com.whalert.app.domain.model.User
import com.whalert.app.util.Resource
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

interface AuthRepository {
    
    /**
     * Register a new user with email and password
     */
    suspend fun register(email: String, password: String, displayName: String): Resource<FirebaseUser>
    
    /**
     * Login with email and password
     */
    suspend fun login(email: String, password: String): Resource<FirebaseUser>
    
    /**
     * Logout the current user
     */
    suspend fun logout(): Resource<Unit>
    
    /**
     * Get the current authenticated user
     */
    fun getCurrentUser(): FirebaseUser?
    
    /**
     * Check if a user is logged in
     */
    fun isLoggedIn(): Boolean
    
    /**
     * Send password reset email
     */
    suspend fun sendPasswordResetEmail(email: String): Resource<Unit>
    
    /**
     * Update user profile
     */
    suspend fun updateProfile(displayName: String?, photoUri: String?): Resource<Unit>
    
    /**
     * Verify email
     */
    suspend fun sendEmailVerification(): Resource<Unit>
    
    /**
     * Delete user account
     */
    suspend fun deleteAccount(): Resource<Unit>
}

class AuthRepositoryImpl(
    private val firebaseAuth: FirebaseAuth,
    private val firebaseFirestore: FirebaseFirestore,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : AuthRepository {
    
    override suspend fun register(email: String, password: String, displayName: String): Resource<FirebaseUser> {
        return withContext(dispatcher) {
            try {
                val result = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
                val user = result.user ?: return@withContext Resource.error("User creation failed", null)
                
                // Update display name
                val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                    .setDisplayName(displayName)
                    .build()
                user.updateProfile(profileUpdates).await()
                
                // Create user document in Firestore
                val userEntity = UserEntity(
                    id = user.uid,
                    email = user.email ?: "",
                    displayName = displayName,
                    isEmailVerified = user.isEmailVerified
                )
                firebaseFirestore.collection("users")
                    .document(user.uid)
                    .set(userEntity)
                    .await()
                
                Resource.success(user)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Registration failed", null)
            }
        }
    }
    
    override suspend fun login(email: String, password: String): Resource<FirebaseUser> {
        return withContext(dispatcher) {
            try {
                val result = firebaseAuth.signInWithEmailAndPassword(email, password).await()
                val user = result.user ?: return@withContext Resource.error("Login failed", null)
                Resource.success(user)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Login failed", null)
            }
        }
    }
    
    override suspend fun logout(): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                firebaseAuth.signOut()
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Logout failed", null)
            }
        }
    }
    
    override fun getCurrentUser(): FirebaseUser? {
        return firebaseAuth.currentUser
    }
    
    override fun isLoggedIn(): Boolean {
        return firebaseAuth.currentUser != null
    }
    
    override suspend fun sendPasswordResetEmail(email: String): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                firebaseAuth.sendPasswordResetEmail(email).await()
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to send reset email", null)
            }
        }
    }
    
    override suspend fun updateProfile(displayName: String?, photoUri: String?): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                val user = firebaseAuth.currentUser ?: return@withContext Resource.error("No user logged in", null)
                
                val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                    .apply {
                        displayName?.let { setDisplayName(it) }
                        photoUri?.let { setPhotoUri(Uri.parse(it)) }
                    }
                    .build()
                
                user.updateProfile(profileUpdates).await()
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to update profile", null)
            }
        }
    }
    
    override suspend fun sendEmailVerification(): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                val user = firebaseAuth.currentUser ?: return@withContext Resource.error("No user logged in", null)
                user.sendEmailVerification().await()
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to send verification email", null)
            }
        }
    }
    
    override suspend fun deleteAccount(): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                val user = firebaseAuth.currentUser ?: return@withContext Resource.error("No user logged in", null)
                
                // Delete user document from Firestore
                firebaseFirestore.collection("users")
                    .document(user.uid)
                    .delete()
                    .await()
                
                user.delete().await()
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to delete account", null)
            }
        }
    }
}
