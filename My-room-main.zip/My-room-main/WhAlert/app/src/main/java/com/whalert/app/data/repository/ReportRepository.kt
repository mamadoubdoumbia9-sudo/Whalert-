package com.whalert.app.data.repository

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.whalert.app.data.local.ReportDao
import com.whalert.app.data.local.entity.ReportEntity
import com.whalert.app.data.remote.EmailService
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.model.ReportStatus
import com.whalert.app.util.Resource
import com.whalert.app.util.mappers.toDomain
import com.whalert.app.util.mappers.toEntity
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Date
import java.util.UUID

interface ReportRepository {
    
    /**
     * Create a new report (local only)
     */
    suspend fun createReport(
        userId: String,
        phoneNumber: String,
        countryCode: String,
        category: ReportCategory,
        description: String,
        date: Date?,
        time: String?,
        evidenceText: List<String>?,
        evidenceImagePaths: List<String>?
    ): Resource<Report>
    
    /**
     * Get a report by ID
     */
    suspend fun getReportById(reportId: String): Resource<Report?>
    
    /**
     * Get all reports for the current user
     */
    fun getAllReports(): Flow<Resource<List<Report>>>
    
    /**
     * Update a report
     */
    suspend fun updateReport(report: Report): Resource<Report>
    
    /**
     * Delete a report
     */
    suspend fun deleteReport(reportId: String): Resource<Unit>
    
    /**
     * Submit a report (transmit to official channels)
     */
    suspend fun submitReport(reportId: String): Resource<Report>
    
    /**
     * Get the status of a report
     */
    suspend fun getReportStatus(reportId: String): Resource<ReportStatus>
    
    /**
     * Get daily report count for the current user
     */
    suspend fun getDailyReportCount(userId: String): Resource<Int>
    
    /**
     * Check if user can submit more reports today
     */
    suspend fun canSubmitReport(userId: String): Resource<Boolean>
    
    /**
     * Upload evidence images to Firebase Storage
     */
    suspend fun uploadEvidenceImages(imageUris: List<Uri>): Resource<List<String>>
    
    /**
     * Generate the official WhatsApp report URL
     */
    fun generateOfficialReportUrl(phoneNumber: String): String
    
    /**
     * Send report via email
     */
    suspend fun sendReportEmail(report: Report, email: String): Resource<Boolean>
}

class ReportRepositoryImpl(
    private val reportDao: ReportDao,
    private val firebaseFirestore: FirebaseFirestore,
    private val firebaseStorage: FirebaseStorage,
    private val emailService: EmailService,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : ReportRepository {
    
    override suspend fun createReport(
        userId: String,
        phoneNumber: String,
        countryCode: String,
        category: ReportCategory,
        description: String,
        date: Date?,
        time: String?,
        evidenceText: List<String>?,
        evidenceImagePaths: List<String>?
    ): Resource<Report> {
        return withContext(dispatcher) {
            try {
                val reportId = UUID.randomUUID().toString()
                
                val reportEntity = ReportEntity(
                    id = reportId,
                    userId = userId,
                    phoneNumber = phoneNumber,
                    countryCode = countryCode,
                    category = category,
                    description = description,
                    date = date,
                    time = time,
                    evidenceText = evidenceText,
                    evidenceImages = null, // Will be uploaded separately if needed
                    status = ReportStatus.DRAFT,
                    createdAt = Date(),
                    updatedAt = Date()
                )
                
                reportDao.insertReport(reportEntity)
                
                // Also save to Firestore for backup and sync
                saveToFirestore(reportEntity)
                
                Resource.success(reportEntity.toDomain())
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to create report", null)
            }
        }
    }
    
    override suspend fun getReportById(reportId: String): Resource<Report?> {
        return withContext(dispatcher) {
            try {
                val reportEntity = reportDao.getReportById(reportId)
                Resource.success(reportEntity?.toDomain())
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get report", null)
            }
        }
    }
    
    override fun getAllReports(): Flow<Resource<List<Report>>> {
        return reportDao.getAllReports().map { reportEntities ->
            try {
                Resource.success(reportEntities.map { it.toDomain() })
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get reports", null)
            }
        }
    }
    
    override suspend fun updateReport(report: Report): Resource<Report> {
        return withContext(dispatcher) {
            try {
                val reportEntity = report.toEntity()
                reportDao.updateReport(reportEntity)
                updateInFirestore(reportEntity)
                Resource.success(report)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to update report", null)
            }
        }
    }
    
    override suspend fun deleteReport(reportId: String): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                reportDao.deleteReport(reportId)
                deleteFromFirestore(reportId)
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to delete report", null)
            }
        }
    }
    
    override suspend fun submitReport(reportId: String): Resource<Report> {
        return withContext(dispatcher) {
            try {
                val reportEntity = reportDao.getReportById(reportId)
                    ?: return@withContext Resource.error("Report not found", null)
                
                // Update status to SUBMITTED
                val updatedReport = reportEntity.copy(
                    status = ReportStatus.SUBMITTED,
                    submittedAt = Date(),
                    updatedAt = Date()
                )
                
                reportDao.updateReport(updatedReport)
                updateInFirestore(updatedReport)
                
                // Note: We cannot actually submit to WhatsApp via API
                // The user must use official channels
                // This just marks it as submitted from our app
                
                Resource.success(updatedReport.toDomain())
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to submit report", null)
            }
        }
    }
    
    override suspend fun getReportStatus(reportId: String): Resource<ReportStatus> {
        return withContext(dispatcher) {
            try {
                val reportEntity = reportDao.getReportById(reportId)
                    ?: return@withContext Resource.error("Report not found", null)
                Resource.success(reportEntity.status)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get report status", null)
            }
        }
    }
    
    override suspend fun getDailyReportCount(userId: String): Resource<Int> {
        return withContext(dispatcher) {
            try {
                val calendar = java.util.Calendar.getInstance()
                calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
                calendar.set(java.util.Calendar.MINUTE, 0)
                calendar.set(java.util.Calendar.SECOND, 0)
                calendar.set(java.util.Calendar.MILLISECOND, 0)
                
                val startDate = calendar.time
                val count = reportDao.getDailyReportCount(userId, startDate)
                Resource.success(count)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get daily report count", null)
            }
        }
    }
    
    override suspend fun canSubmitReport(userId: String): Resource<Boolean> {
        return withContext(dispatcher) {
            try {
                val count = getDailyReportCount(userId).data ?: 0
                Resource.success(count < 3) // Default limit of 3
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to check report limit", null)
            }
        }
    }
    
    override suspend fun uploadEvidenceImages(imageUris: List<Uri>): Resource<List<String>> {
        return withContext(dispatcher) {
            try {
                val downloadUrls = mutableListOf<String>()
                
                imageUris.forEachIndexed { index, uri ->
                    val ref = firebaseStorage.reference
                        .child("evidence")
                        .child(UUID.randomUUID().toString())
                    
                    ref.putFile(uri).await()
                    val downloadUrl = ref.downloadUrl.await().toString()
                    downloadUrls.add(downloadUrl)
                }
                
                Resource.success(downloadUrls)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to upload evidence", null)
            }
        }
    }
    
    override fun generateOfficialReportUrl(phoneNumber: String): String {
        // This generates the official WhatsApp URL for reporting
        // Note: WhatsApp does not provide a direct API for reporting
        // Users must use the official app
        return "https://wa.me/$phoneNumber"
    }
    
    override suspend fun sendReportEmail(report: Report, email: String): Resource<Boolean> {
        return withContext(dispatcher) {
            try {
                val result = emailService.sendReportEmail(report, email)
                Resource.success(result)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to send email", null)
            }
        }
    }
    
    // Private helper methods
    
    private suspend fun saveToFirestore(reportEntity: ReportEntity) {
        try {
            firebaseFirestore.collection("reports")
                .document(reportEntity.id)
                .set(reportEntity)
                .await()
        } catch (e: Exception) {
            // Log error but don't fail the operation
            e.printStackTrace()
        }
    }
    
    private suspend fun updateInFirestore(reportEntity: ReportEntity) {
        try {
            firebaseFirestore.collection("reports")
                .document(reportEntity.id)
                .set(reportEntity)
                .await()
        } catch (e: Exception) {
            // Log error but don't fail the operation
            e.printStackTrace()
        }
    }
    
    private suspend fun deleteFromFirestore(reportId: String) {
        try {
            firebaseFirestore.collection("reports")
                .document(reportId)
                .delete()
                .await()
        } catch (e: Exception) {
            // Log error but don't fail the operation
            e.printStackTrace()
        }
    }
}
