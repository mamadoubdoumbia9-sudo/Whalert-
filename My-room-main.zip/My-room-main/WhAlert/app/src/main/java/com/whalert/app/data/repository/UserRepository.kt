package com.whalert.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.whalert.app.data.local.UserDao
import com.whalert.app.data.local.entity.UserEntity
import com.whalert.app.domain.model.User
import com.whalert.app.util.Resource
import com.whalert.app.util.mappers.toDomain
import com.whalert.app.util.mappers.toEntity
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

interface UserRepository {
    
    /**
     * Get user by ID
     */
    suspend fun getUserById(userId: String): Resource<User?>
    
    /**
     * Get current user
     */
    suspend fun getCurrentUser(): Resource<User?>
    
    /**
     * Get user by email
     */
    suspend fun getUserByEmail(email: String): Resource<User?>
    
    /**
     * Update user profile
     */
    suspend fun updateUser(user: User): Resource<User>
    
    /**
     * Update daily report count
     */
    suspend fun incrementReportCount(userId: String): Resource<Unit>
    
    /**
     * Reset daily report count
     */
    suspend fun resetDailyReportCount(userId: String): Resource<Unit>
    
    /**
     * Update user's last report date
     */
    suspend fun updateLastReportDate(userId: String): Resource<Unit>
    
    /**
     * Check if user can submit more reports today
     */
    suspend fun canSubmitMoreReports(userId: String): Resource<Boolean>
}

class UserRepositoryImpl(
    private val userDao: UserDao,
    private val firebaseFirestore: FirebaseFirestore,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : UserRepository {
    
    override suspend fun getUserById(userId: String): Resource<User?> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getUserById(userId)
                Resource.success(userEntity?.toDomain())
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get user", null)
            }
        }
    }
    
    override suspend fun getCurrentUser(): Resource<User?> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getCurrentUser()
                Resource.success(userEntity?.toDomain())
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get current user", null)
            }
        }
    }
    
    override suspend fun getUserByEmail(email: String): Resource<User?> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getUserByEmail(email)
                Resource.success(userEntity?.toDomain())
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to get user by email", null)
            }
        }
    }
    
    override suspend fun updateUser(user: User): Resource<User> {
        return withContext(dispatcher) {
            try {
                val userEntity = user.toEntity()
                userDao.insertUser(userEntity)
                updateInFirestore(userEntity)
                Resource.success(user)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to update user", null)
            }
        }
    }
    
    override suspend fun incrementReportCount(userId: String): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getUserById(userId)
                    ?: return@withContext Resource.error("User not found", null)
                
                val updatedUser = userEntity.copy(
                    reportCountToday = userEntity.reportCountToday + 1
                )
                
                userDao.updateUser(updatedUser)
                updateInFirestore(updatedUser)
                
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to increment report count", null)
            }
        }
    }
    
    override suspend fun resetDailyReportCount(userId: String): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getUserById(userId)
                    ?: return@withContext Resource.error("User not found", null)
                
                val updatedUser = userEntity.copy(
                    reportCountToday = 0
                )
                
                userDao.updateUser(updatedUser)
                updateInFirestore(updatedUser)
                
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to reset report count", null)
            }
        }
    }
    
    override suspend fun updateLastReportDate(userId: String): Resource<Unit> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getUserById(userId)
                    ?: return@withContext Resource.error("User not found", null)
                
                val updatedUser = userEntity.copy(
                    lastReportDate = java.util.Date()
                )
                
                userDao.updateUser(updatedUser)
                updateInFirestore(updatedUser)
                
                Resource.success(Unit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to update last report date", null)
            }
        }
    }
    
    override suspend fun canSubmitMoreReports(userId: String): Resource<Boolean> {
        return withContext(dispatcher) {
            try {
                val userEntity = userDao.getUserById(userId)
                    ?: return@withContext Resource.error("User not found", null)
                
                Resource.success(userEntity.reportCountToday < userEntity.dailyReportLimit)
            } catch (e: Exception) {
                Resource.error(e.message ?: "Failed to check report limit", null)
            }
        }
    }
    
    // Private helper methods
    
    private suspend fun updateInFirestore(userEntity: UserEntity) {
        try {
            firebaseFirestore.collection("users")
                .document(userEntity.id)
                .set(userEntity)
                .await()
        } catch (e: Exception) {
            // Log error but don't fail the operation
            e.printStackTrace()
        }
    }
}
