package com.whalert.app.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import com.whalert.app.data.local.AppDatabase
import com.whalert.app.data.local.ReportDao
import com.whalert.app.data.local.UserPreferencesRepository
import com.whalert.app.data.remote.WhatsAppApiService
import com.whalert.app.data.repository.AuthRepository
import com.whalert.app.data.repository.AuthRepositoryImpl
import com.whalert.app.data.repository.ReportRepository
import com.whalert.app.data.repository.ReportRepositoryImpl
import com.whalert.app.data.repository.UserRepository
import com.whalert.app.data.repository.UserRepositoryImpl
import com.whalert.app.domain.usecase.auth.GetCurrentUserUseCase
import com.whalert.app.domain.usecase.auth.LoginUseCase
import com.whalert.app.domain.usecase.auth.LogoutUseCase
import com.whalert.app.domain.usecase.auth.RegisterUseCase
import com.whalert.app.domain.usecase.report.*
import com.whalert.app.domain.usecase.user.GetUserProfileUseCase
import com.whalert.app.domain.usecase.user.UpdateUserProfileUseCase
import com.whalert.app.presentation.viewmodel.*
import com.whalert.app.util.Constants
import com.whalert.app.util.NetworkMonitor
import com.whalert.app.util.PhoneNumberValidator
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

// Database version
private const val DATABASE_VERSION = 1

val appModule = module {
    single { provideDataStore(androidContext()) }
    single { provideOkHttpClient() }
    single { provideRetrofit(get()) }
    single { provideWhatsAppApiService(get()) }
    single { provideFirebaseAuth() }
    single { provideFirebaseFirestore() }
    single { provideFirebaseStorage() }
    single { provideNetworkMonitor(androidContext()) }
    single { PhoneNumberValidator() }
}

val dataModule = module {
    single { 
        Room.databaseBuilder(
            androidContext(),
            AppDatabase::class.java,
            Constants.DATABASE_NAME
        ).fallbackToDestructiveMigration()
            .build()
    }
    
    single { get<AppDatabase>().reportDao() }
    
    single { UserPreferencesRepository(get()) }
    
    single<AuthRepository> { AuthRepositoryImpl(get(), get()) }
    single<ReportRepository> { ReportRepositoryImpl(get(), get(), get()) }
    single<UserRepository> { UserRepositoryImpl(get(), get()) }
}

val domainModule = module {
    // Auth Use Cases
    factory { LoginUseCase(get()) }
    factory { RegisterUseCase(get()) }
    factory { LogoutUseCase(get()) }
    factory { GetCurrentUserUseCase(get()) }
    
    // Report Use Cases
    factory { CreateReportUseCase(get()) }
    factory { GetReportByIdUseCase(get()) }
    factory { GetAllReportsUseCase(get()) }
    factory { UpdateReportUseCase(get()) }
    factory { DeleteReportUseCase(get()) }
    factory { SubmitReportUseCase(get()) }
    factory { GetReportStatusUseCase(get()) }
    factory { ValidateReportUseCase() }
    factory { GetDailyReportCountUseCase(get()) }
    factory { CanSubmitReportUseCase(get()) }
    
    // User Use Cases
    factory { GetUserProfileUseCase(get()) }
    factory { UpdateUserProfileUseCase(get()) }
}

val presentationModule = module {
    // ViewModels
    viewModel { HomeViewModel(get(), get(), get()) }
    viewModel { AuthViewModel(get(), get(), get()) }
    viewModel { ReportViewModel(get(), get(), get(), get(), get()) }
    viewModel { ReportDetailViewModel(get(), get()) }
    viewModel { ReportHistoryViewModel(get(), get()) }
    viewModel { SettingsViewModel(get()) }
    viewModel { AdminConsoleViewModel(get(), get()) }
    viewModel { TransparencyViewModel() }
    viewModel { SafetyGuideViewModel() }
}

// Providers

private fun provideDataStore(context: Context): DataStore<Preferences> {
    return context.dataStore
}

private fun provideOkHttpClient(): OkHttpClient {
    val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }
    
    return OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
}

private fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
    return Retrofit.Builder()
        .baseUrl(Constants.BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
}

private fun provideWhatsAppApiService(retrofit: Retrofit): WhatsAppApiService {
    return retrofit.create(WhatsAppApiService::class.java)
}

private fun provideFirebaseAuth(): FirebaseAuth {
    return Firebase.auth
}

private fun provideFirebaseFirestore(): FirebaseFirestore {
    return Firebase.firestore
}

private fun provideFirebaseStorage(): FirebaseStorage {
    return Firebase.storage
}

private fun provideNetworkMonitor(context: Context): NetworkMonitor {
    return NetworkMonitor(context)
}
