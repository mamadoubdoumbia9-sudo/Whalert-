package com.whalert.app.di

// This file exports all Koin modules for easy import

val allModules = listOf(
    appModule,
    dataModule,
    domainModule,
    presentationModule
)
