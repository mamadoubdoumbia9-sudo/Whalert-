package com.whalert.app.domain.model

enum class ModerationDecision {
    UNKNOWN,
    NO_CONFIRMATION_AVAILABLE,
    INFORMATION_OFFICIALLY_AVAILABLE,
    ACTION_SIGNALED_BY_WHATSAPP;
    
    fun getDisplayName(): String {
        return when (this) {
            UNKNOWN -> "Unknown"
            NO_CONFIRMATION_AVAILABLE -> "No confirmation available"
            INFORMATION_OFFICIALLY_AVAILABLE -> "Information officially available"
            ACTION_SIGNALED_BY_WHATSAPP -> "Action signaled by WhatsApp"
        }
    }
    
    fun getDescription(): String {
        return when (this) {
            UNKNOWN -> "WhatsApp decision is unknown"
            NO_CONFIRMATION_AVAILABLE -> "WhatsApp does not provide public confirmation"
            INFORMATION_OFFICIALLY_AVAILABLE -> "Official information is available"
            ACTION_SIGNALED_BY_WHATSAPP -> "WhatsApp has signaled that action was taken"
        }
    }
}
