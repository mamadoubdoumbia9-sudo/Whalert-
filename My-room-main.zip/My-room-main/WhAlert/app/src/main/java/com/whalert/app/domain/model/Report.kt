package com.whalert.app.domain.model

import java.util.Date

data class Report(
    val id: String,
    val userId: String,
    val phoneNumber: String,
    val countryCode: String,
    val category: ReportCategory,
    val description: String,
    val date: Date? = null,
    val time: String? = null,
    val evidenceText: List<String>? = null,
    val evidenceImagePaths: List<String>? = null,
    val status: ReportStatus = ReportStatus.DRAFT,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date(),
    val submittedAt: Date? = null,
    val confirmationReceived: Boolean = false,
    val confirmationDetails: String? = null,
    val officialDecision: String? = null
) {
    fun getFullPhoneNumber(): String {
        return "$countryCode$phoneNumber"
    }
    
    fun getFormattedDate(): String {
        return date?.let { "${it.day}/${it.month + 1}/${it.year + 1900}" } ?: "N/A"
    }
    
    fun getFormattedTime(): String {
        return time ?: "N/A"
    }
    
    fun hasEvidence(): Boolean {
        return !evidenceText.isNullOrEmpty() || !evidenceImagePaths.isNullOrEmpty()
    }
    
    fun getEvidenceCount(): Int {
        return (evidenceText?.size ?: 0) + (evidenceImagePaths?.size ?: 0)
    }
    
    fun isSubmitted(): Boolean {
        return status == ReportStatus.SUBMITTED || 
               status == ReportStatus.CONFIRMATION_RECEIVED ||
               status == ReportStatus.FOLLOW_UP_NEEDED ||
               status == ReportStatus.CLOSED
    }
}
