package com.whalert.app.domain.model

enum class ReportCategory {
    SPAM,
    SCAMS,
    IMPERSONATION,
    HARASSMENT,
    FRAUDULENT_CONTENT,
    MALICIOUS_BEHAVIOR,
    OTHER;
    
    fun getDisplayName(): String {
        return when (this) {
            SPAM -> "Spam"
            SCAMS -> "Scams"
            IMPERSONATION -> "Impersonation"
            HARASSMENT -> "Harassment"
            FRAUDULENT_CONTENT -> "Fraudulent Content"
            MALICIOUS_BEHAVIOR -> "Malicious Behavior"
            OTHER -> "Other"
        }
    }
    
    fun getDescription(): String {
        return when (this) {
            SPAM -> "Unwanted or repeated messages"
            SCAMS -> "Fraudulent schemes or deceptive practices"
            IMPERSONATION -> "Someone pretending to be you or someone else"
            HARASSMENT -> "Abusive or threatening behavior"
            FRAUDULENT_CONTENT -> "False or misleading information"
            MALICIOUS_BEHAVIOR -> "Harmful or suspicious activities"
            OTHER -> "Other concerns"
        }
    }
    
    fun getIconName(): String {
        return when (this) {
            SPAM -> "ic_spam"
            SCAMS -> "ic_scams"
            IMPERSONATION -> "ic_impersonation"
            HARASSMENT -> "ic_harassment"
            FRAUDULENT_CONTENT -> "ic_fraud"
            MALICIOUS_BEHAVIOR -> "ic_malicious"
            OTHER -> "ic_other"
        }
    }
}
