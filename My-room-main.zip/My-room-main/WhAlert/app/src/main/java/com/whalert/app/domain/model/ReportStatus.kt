package com.whalert.app.domain.model

enum class ReportStatus {
    DRAFT,
    PREPARED,
    SUBMITTED,
    CONFIRMATION_RECEIVED,
    FOLLOW_UP_NEEDED,
    CLOSED;
    
    fun getDisplayName(): String {
        return when (this) {
            DRAFT -> "Draft"
            PREPARED -> "Prepared"
            SUBMITTED -> "Submitted"
            CONFIRMATION_RECEIVED -> "Confirmation Received"
            FOLLOW_UP_NEEDED -> "Follow-up Needed"
            CLOSED -> "Closed"
        }
    }
    
    fun getDescription(): String {
        return when (this) {
            DRAFT -> "Report is being created"
            PREPARED -> "Report is ready for review"
            SUBMITTED -> "Report has been sent from this application"
            CONFIRMATION_RECEIVED -> "Confirmation has been received"
            FOLLOW_UP_NEEDED -> "Requires follow-up action"
            CLOSED -> "Report is closed"
        }
    }
    
    fun getColorResName(): String {
        return when (this) {
            DRAFT -> "status_pending"
            PREPARED -> "status_processing"
            SUBMITTED -> "status_processing"
            CONFIRMATION_RECEIVED -> "status_success"
            FOLLOW_UP_NEEDED -> "status_warning"
            CLOSED -> "status_cancelled"
        }
    }
}
