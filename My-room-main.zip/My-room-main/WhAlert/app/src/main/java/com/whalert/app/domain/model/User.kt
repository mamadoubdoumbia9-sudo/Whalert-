package com.whalert.app.domain.model

import java.util.Date

data class User(
    val id: String,
    val email: String,
    val displayName: String? = null,
    val phoneNumber: String? = null,
    val avatarUrl: String? = null,
    val isAdmin: Boolean = false,
    val isEmailVerified: Boolean = false,
    val dailyReportLimit: Int = 3,
    val lastReportDate: Date? = null,
    val reportCountToday: Int = 0,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
) {
    fun getInitials(): String {
        return displayName?.take(2)?.uppercase() ?: email.take(2).uppercase()
    }
    
    fun canSubmitMoreReports(): Boolean {
        return reportCountToday < dailyReportLimit
    }
    
    fun getRemainingReports(): Int {
        return dailyReportLimit - reportCountToday
    }
}
