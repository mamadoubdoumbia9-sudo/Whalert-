package com.whalert.app.domain.usecase.auth

import com.whalert.app.data.repository.AuthRepository
import com.whalert.app.domain.model.User
import com.whalert.app.util.Resource
import com.whalert.app.util.mappers.toDomain

class GetCurrentUserUseCase(private val authRepository: AuthRepository) {
    
    operator fun invoke(): Resource<User?> {
        val firebaseUser = authRepository.getCurrentUser()
        return if (firebaseUser != null) {
            Resource.success(firebaseUser.toDomain())
        } else {
            Resource.success(null)
        }
    }
}
