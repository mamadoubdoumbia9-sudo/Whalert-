package com.whalert.app.domain.usecase.auth

import com.whalert.app.data.repository.AuthRepository
import com.whalert.app.util.Resource
import com.whalert.app.util.ValidationResult

class LoginUseCase(private val authRepository: AuthRepository) {
    
    suspend operator fun invoke(email: String, password: String): Resource<Unit> {
        // Validate inputs
        val emailValidation = validateEmail(email)
        if (!emailValidation.isValid()) {
            return Resource.error(emailValidation.getErrorMessage() ?: "Invalid email")
        }
        
        val passwordValidation = validatePassword(password)
        if (!passwordValidation.isValid()) {
            return Resource.error(passwordValidation.getErrorMessage() ?: "Invalid password")
        }
        
        return authRepository.login(email, password)
    }
    
    private fun validateEmail(email: String): ValidationResult {
        if (email.isBlank()) {
            return ValidationResult.Invalid("Email cannot be empty")
        }
        
        val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\$[A-Za-z]{2,}\"")
        if (!emailRegex.matches(email)) {
            return ValidationResult.Invalid("Invalid email format")
        }
        
        return ValidationResult.Valid
    }
    
    private fun validatePassword(password: String): ValidationResult {
        if (password.isBlank()) {
            return ValidationResult.Invalid("Password cannot be empty")
        }
        
        if (password.length < 8) {
            return ValidationResult.Invalid("Password must be at least 8 characters")
        }
        
        return ValidationResult.Valid
    }
}
