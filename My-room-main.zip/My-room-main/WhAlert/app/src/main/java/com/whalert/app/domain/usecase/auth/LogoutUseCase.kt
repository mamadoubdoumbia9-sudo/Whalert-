package com.whalert.app.domain.usecase.auth

import com.whalert.app.data.repository.AuthRepository
import com.whalert.app.util.Resource

class LogoutUseCase(private val authRepository: AuthRepository) {
    
    suspend operator fun invoke(): Resource<Unit> {
        return authRepository.logout()
    }
}
