package com.whalert.app.domain.usecase.auth

import com.whalert.app.data.repository.AuthRepository
import com.whalert.app.util.Resource
import com.whalert.app.util.ValidationResult

class RegisterUseCase(private val authRepository: AuthRepository) {
    
    suspend operator fun invoke(email: String, password: String, displayName: String): Resource<Unit> {
        // Validate inputs
        val emailValidation = validateEmail(email)
        if (!emailValidation.isValid()) {
            return Resource.error(emailValidation.getErrorMessage() ?: "Invalid email")
        }
        
        val passwordValidation = validatePassword(password)
        if (!passwordValidation.isValid()) {
            return Resource.error(passwordValidation.getErrorMessage() ?: "Invalid password")
        }
        
        val nameValidation = validateName(displayName)
        if (!nameValidation.isValid()) {
            return Resource.error(nameValidation.getErrorMessage() ?: "Invalid name")
        }
        
        return authRepository.register(email, password, displayName)
    }
    
    private fun validateEmail(email: String): ValidationResult {
        if (email.isBlank()) {
            return ValidationResult.Invalid("Email cannot be empty")
        }
        
        val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\$[A-Za-z]{2,}\"")
        if (!emailRegex.matches(email)) {
            return ValidationResult.Invalid("Invalid email format")
        }
        
        return ValidationResult.Valid
    }
    
    private fun validatePassword(password: String): ValidationResult {
        if (password.isBlank()) {
            return ValidationResult.Invalid("Password cannot be empty")
        }
        
        if (password.length < 8) {
            return ValidationResult.Invalid("Password must be at least 8 characters")
        }
        
        // Check for at least one uppercase letter
        if (!password.any { it.isUpperCase() }) {
            return ValidationResult.Invalid("Password must contain at least one uppercase letter")
        }
        
        // Check for at least one lowercase letter
        if (!password.any { it.isLowerCase() }) {
            return ValidationResult.Invalid("Password must contain at least one lowercase letter")
        }
        
        // Check for at least one digit
        if (!password.any { it.isDigit() }) {
            return ValidationResult.Invalid("Password must contain at least one digit")
        }
        
        return ValidationResult.Valid
    }
    
    private fun validateName(name: String): ValidationResult {
        if (name.isBlank()) {
            return ValidationResult.Invalid("Name cannot be empty")
        }
        
        if (name.length < 2) {
            return ValidationResult.Invalid("Name must be at least 2 characters")
        }
        
        if (name.length > 50) {
            return ValidationResult.Invalid("Name must be less than 50 characters")
        }
        
        return ValidationResult.Valid
    }
}
