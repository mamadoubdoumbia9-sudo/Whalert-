package com.whalert.app.domain.usecase.report

import com.whalert.app.data.repository.ReportRepository
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.util.PhoneNumberValidator
import com.whalert.app.util.Resource
import com.whalert.app.util.ValidationResult
import java.util.Date

class CreateReportUseCase(private val reportRepository: ReportRepository) {
    
    private val phoneValidator = PhoneNumberValidator()
    
    suspend operator fun invoke(
        userId: String,
        phoneNumber: String,
        countryCode: String,
        category: ReportCategory,
        description: String,
        date: Date?,
        time: String?,
        evidenceText: List<String>?,
        evidenceImagePaths: List<String>?
    ): Resource<Report> {
        // Validate inputs
        val phoneValidation = validatePhoneNumber(phoneNumber, countryCode)
        if (!phoneValidation.isValid()) {
            return Resource.error(phoneValidation.getErrorMessage() ?: "Invalid phone number")
        }
        
        val categoryValidation = validateCategory(category)
        if (!categoryValidation.isValid()) {
            return Resource.error(categoryValidation.getErrorMessage() ?: "Invalid category")
        }
        
        val descriptionValidation = validateDescription(description)
        if (!descriptionValidation.isValid()) {
            return Resource.error(descriptionValidation.getErrorMessage() ?: "Invalid description")
        }
        
        val evidenceValidation = validateEvidence(evidenceText, evidenceImagePaths)
        if (!evidenceValidation.isValid()) {
            return Resource.error(evidenceValidation.getErrorMessage() ?: "Invalid evidence")
        }
        
        return reportRepository.createReport(
            userId = userId,
            phoneNumber = phoneNumber,
            countryCode = countryCode,
            category = category,
            description = description,
            date = date,
            time = time,
            evidenceText = evidenceText,
            evidenceImagePaths = evidenceImagePaths
        )
    }
    
    private fun validatePhoneNumber(phoneNumber: String, countryCode: String): ValidationResult {
        if (phoneNumber.isBlank()) {
            return ValidationResult.Invalid("Phone number cannot be empty")
        }
        
        if (!phoneValidator.isValidWithCountryCode(phoneNumber, countryCode)) {
            return ValidationResult.Invalid("Invalid phone number format")
        }
        
        return ValidationResult.Valid
    }
    
    private fun validateCategory(category: ReportCategory): ValidationResult {
        // All categories are valid by default
        return ValidationResult.Valid
    }
    
    private fun validateDescription(description: String): ValidationResult {
        if (description.isBlank()) {
            return ValidationResult.Invalid("Description cannot be empty")
        }
        
        if (description.length < 10) {
            return ValidationResult.Invalid("Description must be at least 10 characters")
        }
        
        if (description.length > 2000) {
            return ValidationResult.Invalid("Description must be less than 2000 characters")
        }
        
        return ValidationResult.Valid
    }
    
    private fun validateEvidence(evidenceText: List<String>?, evidenceImagePaths: List<String>?): ValidationResult {
        val totalEvidence = (evidenceText?.size ?: 0) + (evidenceImagePaths?.size ?: 0)
        
        if (totalEvidence > 10) {
            return ValidationResult.Invalid("Maximum 10 evidence items allowed")
        }
        
        evidenceText?.forEach { text ->
            if (text.length > 500) {
                return ValidationResult.Invalid("Evidence text must be less than 500 characters")
            }
        }
        
        return ValidationResult.Valid
    }
}
