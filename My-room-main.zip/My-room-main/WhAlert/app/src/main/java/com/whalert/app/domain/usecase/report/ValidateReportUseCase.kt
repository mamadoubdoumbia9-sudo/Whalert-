package com.whalert.app.domain.usecase.report

import com.whalert.app.domain.model.Report
import com.whalert.app.util.ValidationResult

class ValidateReportUseCase {
    
    operator fun invoke(report: Report): ValidationResult {
        // Check phone number
        if (report.phoneNumber.isBlank()) {
            return ValidationResult.Invalid("Phone number is required")
        }
        
        // Check country code
        if (report.countryCode.isBlank()) {
            return ValidationResult.Invalid("Country code is required")
        }
        
        // Check category
        // Category is an enum, so it's always valid
        
        // Check description
        if (report.description.isBlank()) {
            return ValidationResult.Invalid("Description is required")
        }
        
        if (report.description.length < 10) {
            return ValidationResult.Invalid("Description must be at least 10 characters")
        }
        
        if (report.description.length > 2000) {
            return ValidationResult.Invalid("Description must be less than 2000 characters")
        }
        
        // Check evidence
        val totalEvidence = (report.evidenceText?.size ?: 0) + (report.evidenceImagePaths?.size ?: 0)
        if (totalEvidence > 10) {
            return ValidationResult.Invalid("Maximum 10 evidence items allowed")
        }
        
        return ValidationResult.Valid
    }
}
