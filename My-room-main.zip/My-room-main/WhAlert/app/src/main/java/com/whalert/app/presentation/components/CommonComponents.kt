package com.whalert.app.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography

/**
 * Common reusable components for the WhAlert app
 */

// Loading Indicators

@Composable
fun FullScreenLoading() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            color = MaterialTheme.colorScheme.primary,
            strokeWidth = 3.dp
        )
    }
}

@Composable
fun LinearLoadingIndicator() {
    LinearProgressIndicator(
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.fillMaxWidth()
    )
}

// Buttons

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    icon: ImageVector? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled && !isLoading,
        modifier = modifier.height(WhAlertDimensions.button_height),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        shape = RoundedCornerShape(WhAlertDimensions.button_corner_radius)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp,
                modifier = Modifier.size(WhAlertDimensions.progress_size)
            )
        } else {
            icon?.let { iconVector ->
                Icon(
                    imageVector = iconVector,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_18)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
            }
            Text(
                text = text,
                style = WhAlertTypography.labelLarge
            )
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    icon: ImageVector? = null
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled && !isLoading,
        modifier = modifier.height(WhAlertDimensions.button_height),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = MaterialTheme.colorScheme.primary
        ),
        shape = RoundedCornerShape(WhAlertDimensions.button_corner_radius)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 2.dp,
                modifier = Modifier.size(WhAlertDimensions.progress_size)
            )
        } else {
            icon?.let { iconVector ->
                Icon(
                    imageVector = iconVector,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_18)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
            }
            Text(
                text = text,
                style = WhAlertTypography.labelLarge
            )
        }
    }
}

@Composable
fun TextButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    androidx.compose.material3.TextButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
    ) {
        Text(
            text = text,
            style = WhAlertTypography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

// Cards

@Composable
fun WhAlertCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = WhAlertDimensions.card_elevation
        )
    ) {
        content()
    }
}

// Text Fields

@Composable
fun WhAlertTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String? = null,
    placeholder: String? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    isError: Boolean = false,
    errorMessage: String? = null,
    leadingIcon: ImageVector? = null,
    trailingIcon: ImageVector? = null,
    onTrailingIconClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    maxLines: Int = 1
) {
    Column(
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = label?.let { { Text(it) } },
            placeholder = placeholder?.let { { Text(it) } },
            keyboardOptions = keyboardOptions,
            visualTransformation = visualTransformation,
            isError = isError,
            leadingIcon = leadingIcon?.let { icon ->
                {
                    Icon(
                        imageVector = icon,
                        contentDescription = null
                    )
                }
            },
            trailingIcon = trailingIcon?.let { icon ->
                {
                    IconButton(
                        onClick = onTrailingIconClick ?: {}
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null
                        )
                    }
                }
            },
            singleLine = singleLine,
            minLines = minLines,
            maxLines = maxLines,
            modifier = Modifier.fillMaxWidth()
        )
        
        if (isError && errorMessage != null) {
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_4))
            Text(
                text = errorMessage,
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

// Status Indicators

@Composable
fun StatusBadge(
    text: String,
    status: StatusType = StatusType.INFO,
    modifier: Modifier = Modifier
) {
    val color = when (status) {
        StatusType.SUCCESS -> WhAlertColors.StatusSuccess
        StatusType.ERROR -> WhAlertColors.StatusError
        StatusType.WARNING -> WhAlertColors.StatusWarning
        StatusType.PENDING -> WhAlertColors.StatusPending
        StatusType.INFO -> WhAlertColors.Info
    }
    
    Box(
        modifier = modifier
            .background(color, RoundedCornerShape(WhAlertDimensions.badge_corner_radius))
            .padding(horizontal = WhAlertDimensions.spacing_12, vertical = WhAlertDimensions.spacing_6)
    ) {
        Text(
            text = text,
            style = WhAlertTypography.bodySmall,
            color = Color.White
        )
    }
}

@Composable
fun StatusIcon(
    status: StatusType,
    modifier: Modifier = Modifier
) {
    val (icon, color) = when (status) {
        StatusType.SUCCESS -> Icons.Default.Check to WhAlertColors.StatusSuccess
        StatusType.ERROR -> Icons.Default.Error to WhAlertColors.StatusError
        StatusType.WARNING -> Icons.Default.Warning to WhAlertColors.StatusWarning
        StatusType.PENDING -> Icons.Default.Info to WhAlertColors.StatusPending
        StatusType.INFO -> Icons.Default.Info to WhAlertColors.Info
    }
    
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = color,
        modifier = modifier.size(WhAlertDimensions.icon_size_20)
    )
}

// Alerts

@Composable
fun InfoAlert(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(WhAlertColors.InfoContainer)
            .padding(WhAlertDimensions.spacing_12),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = WhAlertColors.Info
            )
            Text(
                text = message,
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.Info
            )
        }
    }
}

@Composable
fun WarningAlert(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(WhAlertColors.WarningContainer)
            .padding(WhAlertDimensions.spacing_12),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = WhAlertColors.Warning
            )
            Text(
                text = message,
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.Warning
            )
        }
    }
}

@Composable
fun ErrorAlert(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(WhAlertColors.ErrorContainer)
            .padding(WhAlertDimensions.spacing_12),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            Icon(
                imageVector = Icons.Default.Error,
                contentDescription = null,
                tint = WhAlertColors.StatusError
            )
            Text(
                text = message,
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.StatusError
            )
        }
    }
}

@Composable
fun SuccessAlert(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(WhAlertColors.SuccessContainer)
            .padding(WhAlertDimensions.spacing_12),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = WhAlertColors.StatusSuccess
            )
            Text(
                text = message,
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.StatusSuccess
            )
        }
    }
}

// Empty State

@Composable
fun EmptyState(
    title: String,
    description: String,
    icon: ImageVector = Icons.Default.Info,
    onAction: (() -> Unit)? = null,
    actionText: String? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(WhAlertDimensions.spacing_32),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        Text(
            text = title,
            style = WhAlertTypography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = description,
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        
        actionText?.let { text ->
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
            PrimaryButton(
                text = text,
                onClick = { onAction?.invoke() }
            )
        }
    }
}

// Status Types

enum class StatusType {
    SUCCESS,
    ERROR,
    WARNING,
    PENDING,
    INFO
}

// Preview

@Preview(showBackground = true)
@Composable
fun CommonComponentsPreview() {
    MaterialTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(WhAlertDimensions.spacing_16),
            verticalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_16)
        ) {
            PrimaryButton(
                text = "Primary Button",
                onClick = {}
            )
            
            SecondaryButton(
                text = "Secondary Button",
                onClick = {}
            )
            
            TextButton(
                text = "Text Button",
                onClick = {}
            )
            
            StatusBadge(
                text = "Success",
                status = StatusType.SUCCESS
            )
            
            StatusBadge(
                text = "Error",
                status = StatusType.ERROR
            )
            
            StatusBadge(
                text = "Warning",
                status = StatusType.WARNING
            )
            
            InfoAlert(message = "This is an info message")
            WarningAlert(message = "This is a warning message")
            ErrorAlert(message = "This is an error message")
            SuccessAlert(message = "This is a success message")
        }
    }
}
