package com.whalert.app.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.whalert.app.presentation.screens.MainActivity
import com.whalert.app.presentation.screens.admin.AdminConsoleScreen
import com.whalert.app.presentation.screens.auth.LoginScreen
import com.whalert.app.presentation.screens.auth.RegisterScreen
import com.whalert.app.presentation.screens.guide.SafetyGuideScreen
import com.whalert.app.presentation.screens.report.NewReportScreen
import com.whalert.app.presentation.screens.report.ReportDetailScreen
import com.whalert.app.presentation.screens.report.ReportHistoryScreen
import com.whalert.app.presentation.screens.settings.SettingsScreen
import com.whalert.app.presentation.screens.transparency.TransparencyScreen

/**
 * Navigation graph for the WhAlert app
 */

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val NEW_REPORT = "new_report"
    const val REPORT_DETAIL = "report_detail/{reportId}"
    const val REPORT_HISTORY = "report_history"
    const val REPORT_VERIFICATION = "report_verification/{reportId}"
    const val REPORT_STATUS = "report_status/{reportId}"
    const val SAFETY_GUIDE = "safety_guide"
    const val SETTINGS = "settings"
    const val TRANSPARENCY = "transparency"
    const val ADMIN_CONSOLE = "admin_console"
}

object Arguments {
    const val REPORT_ID = "reportId"
}

@Composable
fun WhAlertNavHost() {
    val navController = rememberNavController()
    var isLoggedIn by rememberSaveable { mutableStateOf(false) }
    
    // Check if user is logged in (simplified for now)
    // In a real app, this would check Firebase Auth or local storage
    LaunchedEffect(Unit) {
        // For now, we'll start with login screen
        // In a real app, check auth state
        isLoggedIn = false
    }
    
    NavHost(
        navController = navController,
        startDestination = if (isLoggedIn) Routes.HOME else Routes.LOGIN
    ) {
        // Authentication
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginSuccess = { isLoggedIn = true },
                onNavigateToRegister = { navController.navigate(Routes.REGISTER) }
            )
        }
        
        composable(Routes.REGISTER) {
            RegisterScreen(
                onRegisterSuccess = { 
                    isLoggedIn = true
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToLogin = { navController.navigate(Routes.LOGIN) }
            )
        }
        
        // Main Screens
        composable(Routes.HOME) {
            MainActivity()
        }
        
        composable(Routes.NEW_REPORT) {
            NewReportScreen(
                onBack = { navController.popBackStack() },
                onReportCreated = { reportId ->
                    navController.navigate("${Routes.REPORT_DETAIL.replace("{reportId}", reportId)}") {
                        popUpTo(Routes.NEW_REPORT) { inclusive = true }
                    }
                },
                onNavigateToVerification = { reportId ->
                    navController.navigate("${Routes.REPORT_VERIFICATION.replace("{reportId}", reportId)}")
                }
            )
        }
        
        composable(
            route = Routes.REPORT_DETAIL,
            arguments = listOf(
                androidx.navigation.navArgument(Arguments.REPORT_ID) {
                    type = androidx.navigation.NavType.StringType
                }
            )
        ) { backStackEntry ->
            val reportId = backStackEntry.arguments?.getString(Arguments.REPORT_ID) ?: ""
            ReportDetailScreen(
                reportId = reportId,
                onBack = { navController.popBackStack() },
                onEdit = { 
                    navController.navigate("${Routes.NEW_REPORT}?edit=$reportId")
                },
                onDelete = { 
                    navController.popBackStack()
                }
            )
        }
        
        composable(
            route = Routes.REPORT_VERIFICATION,
            arguments = listOf(
                androidx.navigation.navArgument(Arguments.REPORT_ID) {
                    type = androidx.navigation.NavType.StringType
                }
            )
        ) { backStackEntry ->
            val reportId = backStackEntry.arguments?.getString(Arguments.REPORT_ID) ?: ""
            ReportVerificationScreen(
                reportId = reportId,
                onBack = { navController.popBackStack() },
                onSubmitSuccess = { 
                    navController.navigate("${Routes.REPORT_STATUS.replace("{reportId}", reportId)}") {
                        popUpTo("${Routes.REPORT_VERIFICATION.replace("{reportId}", reportId)}") { inclusive = true }
                    }
                }
            )
        }
        
        composable(
            route = Routes.REPORT_STATUS,
            arguments = listOf(
                androidx.navigation.navArgument(Arguments.REPORT_ID) {
                    type = androidx.navigation.NavType.StringType
                }
            )
        ) { backStackEntry ->
            val reportId = backStackEntry.arguments?.getString(Arguments.REPORT_ID) ?: ""
            ReportStatusScreen(
                reportId = reportId,
                onBack = { navController.popBackStack() },
                onViewDetail = { 
                    navController.navigate("${Routes.REPORT_DETAIL.replace("{reportId}", reportId)}") {
                        popUpTo("${Routes.REPORT_STATUS.replace("{reportId}", reportId)}") { inclusive = true }
                    }
                }
            )
        }
        
        composable(Routes.REPORT_HISTORY) {
            ReportHistoryScreen(
                onBack = { navController.popBackStack() },
                onReportClick = { reportId ->
                    navController.navigate("${Routes.REPORT_DETAIL.replace("{reportId}", reportId)}")
                },
                onNewReport = { navController.navigate(Routes.NEW_REPORT) }
            )
        }
        
        // Settings and Info
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onLogout = { 
                    isLoggedIn = false
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.HOME) { inclusive = true }
                    }
                }
            )
        }
        
        composable(Routes.SAFETY_GUIDE) {
            SafetyGuideScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        composable(Routes.TRANSPARENCY) {
            TransparencyScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // Admin
        composable(Routes.ADMIN_CONSOLE) {
            AdminConsoleScreen(
                onBack = { navController.popBackStack() },
                onLogout = { 
                    isLoggedIn = false
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.HOME) { inclusive = true }
                    }
                }
            )
        }
    }
}

// Placeholder screens for the navigation

@Composable
fun ReportVerificationScreen(
    reportId: String,
    onBack: () -> Unit,
    onSubmitSuccess: () -> Unit
) {
    // Implementation would go here
    // For now, just a placeholder
    SettingsScreen(
        onBack = onBack,
        onLogout = onSubmitSuccess
    )
}

@Composable
fun ReportStatusScreen(
    reportId: String,
    onBack: () -> Unit,
    onViewDetail: () -> Unit
) {
    // Implementation would go here
    // For now, just a placeholder
    SettingsScreen(
        onBack = onBack,
        onLogout = onViewDetail
    )
}
