package com.whalert.app.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.whalert.app.R
import com.whalert.app.domain.model.ReportStatus
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.HomeViewModel
import com.whalert.app.util.Constants
import org.koin.androidx.compose.koinViewModel

@Composable
fun HomeScreen(
    onNavigateToNewReport: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToGuide: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToTransparency: () -> Unit,
    onNavigateToAdminConsole: () -> Unit,
    onLogout: () -> Unit
) {
    val viewModel: HomeViewModel = koinViewModel()
    val state = viewModel.state.collectAsStateWithLifecycle().value
    val context = LocalContext.current
    
    var showAnimation by remember { mutableStateOf(false) }
    
    LaunchedEffect(Unit) {
        showAnimation = true
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        HomeHeader(
            connectionStatus = state.connectionStatus,
            onSettingsClick = onNavigateToSettings
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        // App Logo and Title
        AnimatedVisibility(
            visible = showAnimation,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(
                animationSpec = tween(durationMillis = 500)
            )
        ) {
            HomeHeroSection()
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_32))
        
        // Stats Cards
        if (state.statsVisible) {
            StatsRow(
                totalReports = state.totalReports,
                dailyLimit = state.dailyLimit,
                remainingReports = state.remainingReports
            )
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        }
        
        // Main Actions
        AnimatedVisibility(
            visible = showAnimation,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(
                animationSpec = tween(durationMillis = 500, delayMillis = 100)
            )
        ) {
            MainActionsColumn(
                onNewReport = onNavigateToNewReport,
                onHistory = onNavigateToHistory,
                onGuide = onNavigateToGuide,
                onTransparency = onNavigateToTransparency,
                onAdminConsole = onNavigateToAdminConsole
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_32))
        
        // Feature Highlights
        FeatureHighlights()
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_32))
        
        // Footer
        HomeFooter(
            version = Constants.APP_VERSION,
            onLogout = onLogout
        )
    }
}

@Composable
private fun HomeHeader(
    connectionStatus: String,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = WhAlertDimensions.spacing_16,
                vertical = WhAlertDimensions.spacing_12
            ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = stringResource(R.string.app_name),
            style = WhAlertTypography.titleLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            ConnectionStatusIndicator(status = connectionStatus)
            
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = stringResource(R.string.action_settings),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(WhAlertDimensions.icon_size_24)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onSettingsClick()
                    }
            )
        }
    }
}

@Composable
private fun ConnectionStatusIndicator(status: String) {
    val color = when (status) {
        "Connected" -> WhAlertColors.StatusSuccess
        "Not Connected" -> WhAlertColors.StatusError
        "Session Expired" -> WhAlertColors.StatusWarning
        else -> WhAlertColors.Outline
    }
    
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_4)
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.icon_size_12)
                .background(color, RoundedCornerShape(50))
        )
        Text(
            text = status,
            style = WhAlertTypography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HomeHeroSection() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        // App Icon
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                )
                .padding(WhAlertDimensions.spacing_16),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = stringResource(R.string.app_name),
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        // Title and Subtitle
        Text(
            text = stringResource(R.string.app_name),
            style = WhAlertTypography.headlineLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = stringResource(R.string.app_description),
            style = WhAlertTypography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = WhAlertDimensions.spacing_24)
        )
    }
}

@Composable
private fun StatsRow(
    totalReports: Int,
    dailyLimit: Int,
    remainingReports: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16),
        horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_12)
    ) {
        StatCard(
            title = "Total Reports",
            value = totalReports.toString(),
            icon = Icons.Default.History,
            modifier = Modifier.weight(1f)
        )
        
        StatCard(
            title = "Daily Limit",
            value = "$remainingReports/$dailyLimit",
            icon = Icons.Default.Security,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(
            modifier = Modifier
                .padding(WhAlertDimensions.spacing_12)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(WhAlertDimensions.icon_size_20)
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_4))
            
            Text(
                text = value,
                style = WhAlertTypography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = title,
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MainActionsColumn(
    onNewReport: () -> Unit,
    onHistory: () -> Unit,
    onGuide: () -> Unit,
    onTransparency: () -> Unit,
    onAdminConsole: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Primary Action Button
        Button(
            onClick = onNewReport,
            modifier = Modifier
                .fillMaxWidth()
                .height(WhAlertDimensions.button_height_large),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            shape = RoundedCornerShape(WhAlertDimensions.button_corner_radius_large)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(WhAlertDimensions.icon_size_20)
            )
            Spacer(modifier = Modifier.size(WhAlertDimensions.spacing_8))
            Text(
                text = stringResource(R.string.action_new_report),
                style = WhAlertTypography.labelLarge
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
        
        // Secondary Actions
        ActionCard(
            title = stringResource(R.string.action_my_reports),
            description = stringResource(R.string.report_history_empty_description),
            icon = Icons.Default.History,
            onClick = onHistory
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        ActionCard(
            title = stringResource(R.string.action_safety_guide),
            description = "Learn how to recognize and report suspicious activities",
            icon = Icons.Default.Shield,
            onClick = onGuide
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        ActionCard(
            title = stringResource(R.string.action_transparency),
            description = "What WhAlert can and cannot do",
            icon = Icons.Default.Info,
            onClick = onTransparency
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        // Admin Console (hidden by default)
        ActionCard(
            title = stringResource(R.string.action_admin_console),
            description = "Private administrative interface",
            icon = Icons.Default.VerifiedUser,
            onClick = onAdminConsole,
            showArrow = true
        )
    }
}

@Composable
private fun ActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    showArrow: Boolean = false
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = WhAlertDimensions.card_elevation
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WhAlertDimensions.spacing_16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(WhAlertDimensions.icon_size_24)
            )
            
            Spacer(modifier = Modifier.size(WhAlertDimensions.spacing_12))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = WhAlertTypography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = description,
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            if (showArrow) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_20)
                )
            }
        }
    }
}

@Composable
private fun FeatureHighlights() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Why use WhAlert?",
            style = WhAlertTypography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_12)
        ) {
            FeatureItem(
                title = "Official Channels",
                description = "Uses only WhatsApp's official reporting mechanisms",
                icon = Icons.Default.VerifiedUser,
                modifier = Modifier.weight(1f)
            )
            
            FeatureItem(
                title = "Secure",
                description = "Your data is protected and encrypted",
                icon = Icons.Default.Security,
                modifier = Modifier.weight(1f)
            )
            
            FeatureItem(
                title = "Transparent",
                description = "Clear about what it can and cannot do",
                icon = Icons.Default.Info,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun FeatureItem(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .padding(WhAlertDimensions.spacing_8),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.icon_size_48)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.icon_size_24)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = title,
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
        
        Text(
            text = description,
            style = WhAlertTypography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun HomeFooter(version: String, onLogout: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(WhAlertDimensions.spacing_16),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Version $version",
            style = WhAlertTypography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = stringResource(R.string.legal_disclaimer),
            style = WhAlertTypography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    WhAlertTheme {
        HomeScreen(
            onNavigateToNewReport = {},
            onNavigateToHistory = {},
            onNavigateToGuide = {},
            onNavigateToSettings = {},
            onNavigateToTransparency = {},
            onNavigateToAdminConsole = {},
            onLogout = {}
        )
    }
}
