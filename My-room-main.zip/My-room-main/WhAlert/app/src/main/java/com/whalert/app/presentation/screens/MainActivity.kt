package com.whalert.app.presentation.screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.whalert.app.presentation.screens.admin.AdminConsoleScreen
import com.whalert.app.presentation.screens.auth.LoginScreen
import com.whalert.app.presentation.screens.auth.RegisterScreen
import com.whalert.app.presentation.screens.guide.SafetyGuideScreen
import com.whalert.app.presentation.screens.report.NewReportScreen
import com.whalert.app.presentation.screens.report.ReportDetailScreen
import com.whalert.app.presentation.screens.report.ReportHistoryScreen
import com.whalert.app.presentation.screens.report.ReportStatusScreen
import com.whalert.app.presentation.screens.report.ReportVerificationScreen
import com.whalert.app.presentation.screens.settings.SettingsScreen
import com.whalert.app.presentation.screens.transparency.TransparencyScreen
import com.whalert.app.presentation.theme.WhAlertTheme

class MainActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            WhAlertTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    WhAlertApp()
                }
            }
        }
    }
}

@Composable
fun WhAlertApp() {
    val navController = rememberNavController()
    
    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        composable("splash") {
            SplashScreen(navController = navController)
        }
        
        // Authentication
        composable("login") {
            LoginScreen(
                onLoginSuccess = { navController.navigate("home") {
                    popUpTo("login") { inclusive = true }
                }},
                onNavigateToRegister = { navController.navigate("register") }
            )
        }
        
        composable("register") {
            RegisterScreen(
                onRegisterSuccess = { 
                    navController.navigate("home") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onNavigateToLogin = { navController.navigate("login") }
            )
        }
        
        // Main Screens
        composable("home") {
            HomeScreen(
                onNavigateToNewReport = { navController.navigate("new_report") },
                onNavigateToHistory = { navController.navigate("history") },
                onNavigateToGuide = { navController.navigate("guide") },
                onNavigateToSettings = { navController.navigate("settings") },
                onNavigateToTransparency = { navController.navigate("transparency") },
                onNavigateToAdminConsole = { navController.navigate("admin_console") },
                onLogout = { navController.navigate("login") {
                    popUpTo("home") { inclusive = true }
                } }
            )
        }
        
        composable("new_report") {
            NewReportScreen(
                onBack = { navController.popBackStack() },
                onReportCreated = { reportId ->
                    navController.navigate("report_detail/$reportId") {
                        popUpTo("new_report") { inclusive = true }
                    }
                },
                onNavigateToVerification = { reportId ->
                    navController.navigate("report_verification/$reportId")
                }
            )
        }
        
        composable("report_detail/{reportId}") { backStackEntry ->
            val reportId = backStackEntry.arguments?.getString("reportId") ?: ""
            ReportDetailScreen(
                reportId = reportId,
                onBack = { navController.popBackStack() },
                onEdit = { 
                    navController.navigate("new_report?edit=$reportId")
                },
                onDelete = { 
                    navController.popBackStack()
                }
            )
        }
        
        composable("report_verification/{reportId}") { backStackEntry ->
            val reportId = backStackEntry.arguments?.getString("reportId") ?: ""
            ReportVerificationScreen(
                reportId = reportId,
                onBack = { navController.popBackStack() },
                onSubmitSuccess = { 
                    navController.navigate("report_status/$reportId") {
                        popUpTo("report_verification/$reportId") { inclusive = true }
                    }
                }
            )
        }
        
        composable("report_status/{reportId}") { backStackEntry ->
            val reportId = backStackEntry.arguments?.getString("reportId") ?: ""
            ReportStatusScreen(
                reportId = reportId,
                onBack = { navController.popBackStack() },
                onViewDetail = { 
                    navController.navigate("report_detail/$reportId") {
                        popUpTo("report_status/$reportId") { inclusive = true }
                    }
                }
            )
        }
        
        composable("history") {
            ReportHistoryScreen(
                onBack = { navController.popBackStack() },
                onReportClick = { reportId ->
                    navController.navigate("report_detail/$reportId")
                },
                onNewReport = { navController.navigate("new_report") }
            )
        }
        
        // Settings and Info
        composable("settings") {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onLogout = { 
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }
        
        composable("guide") {
            SafetyGuideScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        composable("transparency") {
            TransparencyScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // Admin
        composable("admin_console") {
            AdminConsoleScreen(
                onBack = { navController.popBackStack() },
                onLogout = { 
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }
    }
}

@Composable
fun SplashScreen(navController: androidx.navigation.NavHostController) {
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.foundation.layout.fillMaxSize(),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.CircularProgressIndicator()
    }
    
    androidx.compose.runtime.LaunchedEffect(Unit) {
        androidx.compose.runtime.delay(2000)
        navController.navigate("login") {
            popUpTo("splash") { inclusive = true }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun WhAlertAppPreview() {
    WhAlertTheme {
        // Preview content
    }
}
