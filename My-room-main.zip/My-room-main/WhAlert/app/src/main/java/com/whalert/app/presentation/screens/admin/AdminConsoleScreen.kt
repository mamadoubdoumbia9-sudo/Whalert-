package com.whalert.app.presentation.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.SystemSecurityUpdate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.whalert.app.R
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.AdminConsoleViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun AdminConsoleScreen(
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val viewModel: AdminConsoleViewModel = koinViewModel()
    val state = viewModel.state.collectAsStateWithLifecycle().value
    
    var showAuthDialog by remember { mutableStateOf(false) }
    var authCode by rememberSaveable { mutableStateOf("") }
    var isAuthenticated by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.admin_console_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
            
            if (!isAuthenticated) {
                // Authentication Required
                AdminAuthSection(
                    onAuthenticate = { code ->
                        // Simple authentication check (in real app, this would be more secure)
                        if (code == "ADMIN123") {
                            isAuthenticated = true
                        } else {
                            // Show error
                        }
                    },
                    onCancel = onBack
                )
            } else {
                // Admin Console Content
                AdminConsoleHeader()
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
                
                // Warning
                WarningBanner()
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Stats
                StatsSection(
                    totalReports = state.totalReports,
                    reportsThisWeek = state.reportsThisWeek,
                    reportsToday = state.reportsToday
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Admin Actions
                AdminActionsSection()
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Logout
                ElevatedCard(
                    onClick = onLogout,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(WhAlertDimensions.spacing_16),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(WhAlertDimensions.spacing_16),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = stringResource(R.string.action_logout),
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(WhAlertDimensions.icon_size_24)
                        )
                        
                        Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
                        
                        Text(
                            text = stringResource(R.string.action_logout),
                            style = WhAlertTypography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        }
    }
}

@Composable
private fun AdminAuthSection(
    onAuthenticate: (String) -> Unit,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WhAlertDimensions.spacing_24),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        Text(
            text = stringResource(R.string.admin_console_auth_title),
            style = WhAlertTypography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = stringResource(R.string.admin_console_auth_subtitle),
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        // Authentication form would go here
        // For simplicity, we'll just show a message
        Text(
            text = "Please authenticate to access the admin console",
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun AdminConsoleHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Dashboard,
                contentDescription = null,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        Text(
            text = stringResource(R.string.admin_console_title),
            style = WhAlertTypography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = stringResource(R.string.admin_console_subtitle),
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun WarningBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(WhAlertColors.WarningContainer)
            .padding(WhAlertDimensions.spacing_12),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            Icon(
                imageVector = Icons.Default.Error,
                contentDescription = null,
                tint = WhAlertColors.Warning
            )
            
            Text(
                text = stringResource(R.string.admin_console_warning),
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.Warning
            )
        }
    }
}

@Composable
private fun StatsSection(
    totalReports: Int,
    reportsThisWeek: Int,
    reportsToday: Int
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16)
    ) {
        Text(
            text = "Statistics",
            style = WhAlertTypography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
        
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = WhAlertDimensions.card_elevation
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(WhAlertDimensions.spacing_16)
            ) {
                StatItem(
                    title = stringResource(R.string.admin_console_stats_total_reports),
                    value = totalReports.toString(),
                    icon = Icons.Default.Assessment
                )
                
                Divider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = WhAlertDimensions.spacing_8),
                    color = MaterialTheme.colorScheme.outlineVariant
                )
                
                StatItem(
                    title = stringResource(R.string.admin_console_stats_total_transmissions),
                    value = reportsThisWeek.toString(),
                    icon = Icons.Default.NetworkCheck
                )
                
                Divider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = WhAlertDimensions.spacing_8),
                    color = MaterialTheme.colorScheme.outlineVariant
                )
                
                StatItem(
                    title = stringResource(R.string.admin_console_stats_errors),
                    value = reportsToday.toString(),
                    icon = Icons.Default.Error
                )
            }
        }
    }
}

@Composable
private fun StatItem(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = WhAlertDimensions.spacing_8),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(WhAlertDimensions.icon_size_24)
        )
        
        Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Text(
                text = value,
                style = WhAlertTypography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun AdminActionsSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16)
    ) {
        Text(
            text = "Admin Actions",
            style = WhAlertTypography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
        
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = WhAlertDimensions.card_elevation
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(WhAlertDimensions.spacing_8)
            ) {
                AdminActionItem(
                    title = stringResource(R.string.admin_console_stats_history),
                    description = "View all reports and actions",
                    icon = Icons.Default.History
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_stats_limits),
                    description = "Configure rate limits and quotas",
                    icon = Icons.Default.Settings
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_stats_logs),
                    description = "View system logs and diagnostics",
                    icon = Icons.Default.Description
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_stats_network_status),
                    description = "Check network connectivity",
                    icon = Icons.Default.NetworkCheck
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_stats_backend_status),
                    description = "Check backend service status",
                    icon = Icons.Default.Monitor
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_stats_service_status),
                    description = "Check all service integrations",
                    icon = Icons.Default.SystemSecurityUpdate
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_config_title),
                    description = "Configure system settings",
                    icon = Icons.Default.Build
                )
                
                AdminActionItem(
                    title = stringResource(R.string.admin_console_diagnostic_title),
                    description = "Run system diagnostics",
                    icon = Icons.Default.BugReport
                )
            }
        }
    }
}

@Composable
private fun AdminActionItem(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                // Action would be triggered here
            }
            .padding(WhAlertDimensions.spacing_16),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(WhAlertDimensions.icon_size_24)
        )
        
        Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = WhAlertTypography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Text(
                text = description,
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .size(WhAlertDimensions.icon_size_20)
                .rotate(180f)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun AdminConsoleScreenPreview() {
    WhAlertTheme {
        AdminConsoleScreen(
            onBack = {},
            onLogout = {}
        )
    }
}

@Composable
fun WhAlertTheme(
    content: @Composable () -> Unit
) {
    // This is a placeholder for the actual theme
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(),
        content = content
    )
}

val CardDefaults = androidx.compose.material3.CardDefaults
