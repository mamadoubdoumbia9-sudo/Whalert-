package com.whalert.app.presentation.screens.report

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.whalert.app.R
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.ReportViewModel
import com.whalert.app.util.PhoneNumberValidator
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

@Composable
fun NewReportScreen(
    onBack: () -> Unit,
    onReportCreated: (String) -> Unit,
    onNavigateToVerification: (String) -> Unit
) {
    val viewModel: ReportViewModel = koinViewModel()
    val state = viewModel.state.collectAsStateWithLifecycle().value
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    // Form state
    var phoneNumber by rememberSaveable { mutableStateOf("") }
    var countryCode by rememberSaveable { mutableStateOf("+223") } // Default to Mali
    var selectedCategory by rememberSaveable { mutableStateOf<ReportCategory?>(null) }
    var description by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf<Date?>(null) }
    var time by rememberSaveable { mutableStateOf("") }
    var evidenceText by rememberSaveable { mutableStateOf(listOf<String>()) }
    var evidenceImages by rememberSaveable { mutableStateOf(listOf<Uri>()) }
    
    var showCategoryDropdown by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    
    // Image picker
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris != null) {
            evidenceImages = (evidenceImages + uris).take(10)
        }
    }
    
    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { uri ->
        if (uri != null) {
            evidenceImages = (evidenceImages + listOf(uri)).take(10)
        }
    }
    
    val phoneValidator = remember { PhoneNumberValidator() }
    
    LaunchedEffect(state.reportCreated) {
        state.reportCreated?.let { reportId ->
            onNavigateToVerification(reportId)
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.report_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
            
            // Progress Indicator
            if (state.isLoading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth()
                )
            }
            
            // Form
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = WhAlertDimensions.spacing_16),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Phone Number Section
                PhoneNumberSection(
                    phoneNumber = phoneNumber,
                    countryCode = countryCode,
                    onPhoneNumberChange = { phoneNumber = it },
                    onCountryCodeChange = { countryCode = it },
                    isValid = phoneValidator.isValidWithCountryCode(phoneNumber, countryCode),
                    phoneValidator = phoneValidator
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Disclaimer
                Text(
                    text = stringResource(R.string.report_phone_disclaimer),
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
                
                // Category Section
                CategorySection(
                    selectedCategory = selectedCategory,
                    onCategorySelected = { category ->
                        selectedCategory = category
                        showCategoryDropdown = false
                    },
                    showDropdown = showCategoryDropdown,
                    onDropdownToggle = { showCategoryDropdown = !showCategoryDropdown }
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Description Section
                DescriptionSection(
                    description = description,
                    onDescriptionChange = { description = it }
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Date and Time Section
                DateTimeSection(
                    date = date,
                    time = time,
                    onDateClick = { showDatePicker = true },
                    onTimeClick = { showTimePicker = true }
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Evidence Section
                EvidenceSection(
                    evidenceText = evidenceText,
                    evidenceImages = evidenceImages,
                    onAddTextEvidence = { newText ->
                        evidenceText = evidenceText + newText
                    },
                    onRemoveTextEvidence = { index ->
                        evidenceText = evidenceText.filterIndexed { i, _ -> i != index }
                    },
                    onAddImageEvidence = {
                        imagePickerLauncher.launch(
                            ActivityResultContracts.PickMultipleVisualMedia().createIntent(
                                context,
                                ActivityResultContracts.PickVisualMedia.ImageAndVideo
                            )
                        )
                    },
                    onRemoveImageEvidence = { index ->
                        evidenceImages = evidenceImages.filterIndexed { i, _ -> i != index }
                    }
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
                
                // Submit Button
                Button(
                    onClick = {
                        if (phoneNumber.isBlank() || !phoneValidator.isValidWithCountryCode(phoneNumber, countryCode)) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Please enter a valid phone number")
                            }
                            return@Button
                        }
                        
                        if (selectedCategory == null) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Please select a category")
                            }
                            return@Button
                        }
                        
                        if (description.isBlank() || description.length < 10) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Please enter a valid description (min 10 characters)")
                            }
                            return@Button
                        }
                        
                        // Create report
                        val reportId = UUID.randomUUID().toString()
                        viewModel.createReport(
                            userId = "current_user_id", // Will be replaced with actual user ID
                            phoneNumber = phoneNumber,
                            countryCode = countryCode,
                            category = selectedCategory!!,
                            description = description,
                            date = date,
                            time = time,
                            evidenceText = evidenceText.ifEmpty { null },
                            evidenceImagePaths = evidenceImages.map { it.toString() }.ifEmpty { null }
                        )
                    },
                    enabled = !state.isLoading && 
                            phoneNumber.isNotBlank() && 
                            phoneValidator.isValidWithCountryCode(phoneNumber, countryCode) &&
                            selectedCategory != null &&
                            description.isNotBlank() &&
                            description.length >= 10,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(WhAlertDimensions.button_height_large)
                ) {
                    if (state.isLoading) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(WhAlertDimensions.progress_size)
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.continue_text),
                            style = WhAlertTypography.labelLarge
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Disclaimer
                Text(
                    text = stringResource(R.string.report_disclaimer),
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
            
            // Date Picker Dialog
            if (showDatePicker) {
                // DatePickerDialog implementation would go here
                // For now, we'll use a simple text input
            }
            
            // Time Picker Dialog
            if (showTimePicker) {
                // TimePickerDialog implementation would go here
            }
        }
    }
}

@Composable
private fun PhoneNumberSection(
    phoneNumber: String,
    countryCode: String,
    onPhoneNumberChange: (String) -> Unit,
    onCountryCodeChange: (String) -> Unit,
    isValid: Boolean,
    phoneValidator: PhoneNumberValidator
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = stringResource(R.string.report_phone_label),
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            // Country Code Picker
            ExposedDropdownMenuBox(
                value = countryCode,
                onValueChange = onCountryCodeChange,
                expanded = false,
                onExpandedChange = {},
                modifier = Modifier.width(WhAlertDimensions.button_min_width)
            ) {
                TextField(
                    value = countryCode,
                    onValueChange = onCountryCodeChange,
                    readOnly = true,
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null
                        )
                    },
                    modifier = Modifier.menuAnchor()
                )
            }
            
            // Phone Number Field
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { newValue ->
                    // Only allow digits
                    if (newValue.all { it.isDigit() }) {
                        onPhoneNumberChange(newValue)
                    }
                },
                label = { Text(stringResource(R.string.report_phone_hint)) },
                placeholder = { Text("123456789") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone
                ),
                singleLine = true,
                isError = phoneNumber.isNotBlank() && !isValid,
                trailingIcon = {
                    if (phoneNumber.isNotBlank()) {
                        if (isValid) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = WhAlertColors.StatusSuccess
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = WhAlertColors.StatusError
                            )
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            )
        }
        
        if (phoneNumber.isNotBlank() && !isValid) {
            Text(
                text = stringResource(R.string.report_phone_error_invalid),
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.StatusError,
                modifier = Modifier.padding(start = WhAlertDimensions.spacing_12)
            )
        }
    }
}

@Composable
private fun CategorySection(
    selectedCategory: ReportCategory?,
    onCategorySelected: (ReportCategory) -> Unit,
    showDropdown: Boolean,
    onDropdownToggle: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = stringResource(R.string.report_category_label),
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        // Category Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            items(ReportCategory.values()) { category ->
                val isSelected = category == selectedCategory
                
                ElevatedCard(
                    onClick = { onCategorySelected(category) },
                    modifier = Modifier
                        .height(WhAlertDimensions.report_form_category_chip_height),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = if (isSelected) {
                            WhAlertDimensions.card_elevation_hovered
                        } else {
                            WhAlertDimensions.card_elevation
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = WhAlertDimensions.spacing_12),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(WhAlertDimensions.icon_size_16)
                            )
                            Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_4))
                        }
                        
                        Text(
                            text = category.getDisplayName(),
                            style = WhAlertTypography.bodySmall,
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        }
        
        if (selectedCategory == null) {
            Text(
                text = "Please select a category",
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.StatusError,
                modifier = Modifier.padding(top = WhAlertDimensions.spacing_8)
            )
        }
    }
}

@Composable
private fun DescriptionSection(
    description: String,
    onDescriptionChange: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = stringResource(R.string.report_description_label),
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        OutlinedTextField(
            value = description,
            onValueChange = onDescriptionChange,
            label = { Text(stringResource(R.string.report_description_hint)) },
            placeholder = { Text("Describe what happened...") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = WhAlertDimensions.report_form_description_field_height),
            minLines = 4,
            maxLines = 8,
            isError = description.isNotBlank() && description.length < 10
        )
        
        if (description.isNotBlank() && description.length < 10) {
            Text(
                text = "Description must be at least 10 characters",
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.StatusError
            )
        }
    }
}

@Composable
private fun DateTimeSection(
    date: Date?,
    time: String,
    onDateClick: () -> Unit,
    onTimeClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = stringResource(R.string.report_date_label) + " & " + stringResource(R.string.report_time_label),
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_12)
        ) {
            // Date Button
            OutlinedButton(
                onClick = onDateClick,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.DateRange,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_18)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
                Text(
                    text = date?.let { "${it.day}/${it.month + 1}/${it.year + 1900}" } ?: "Select Date",
                    style = WhAlertTypography.bodySmall
                )
            }
            
            // Time Button
            OutlinedButton(
                onClick = onTimeClick,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_18)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
                Text(
                    text = time.ifBlank { "Select Time" },
                    style = WhAlertTypography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun EvidenceSection(
    evidenceText: List<String>,
    evidenceImages: List<Uri>,
    onAddTextEvidence: (String) -> Unit,
    onRemoveTextEvidence: (Int) -> Unit,
    onAddImageEvidence: () -> Unit,
    onRemoveImageEvidence: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = stringResource(R.string.report_evidence_label),
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        // Evidence Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_12)
        ) {
            OutlinedButton(
                onClick = { onAddTextEvidence("") },
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.TextFields,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_18)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
                Text(
                    text = stringResource(R.string.report_evidence_add_text),
                    style = WhAlertTypography.bodySmall
                )
            }
            
            OutlinedButton(
                onClick = onAddImageEvidence,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_18)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
                Text(
                    text = stringResource(R.string.report_evidence_add_screenshot),
                    style = WhAlertTypography.bodySmall
                )
            }
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
        
        // Text Evidence
        if (evidenceText.isNotEmpty()) {
            Text(
                text = "Text Evidence (${evidenceText.size})",
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            
            evidenceText.forEachIndexed { index, text ->
                EvidenceTextItem(
                    text = text,
                    onRemove = { onRemoveTextEvidence(index) }
                )
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            }
        }
        
        // Image Evidence
        if (evidenceImages.isNotEmpty()) {
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            Text(
                text = "Image Evidence (${evidenceImages.size})",
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_12)
            ) {
                items(evidenceImages) { uri ->
                    EvidenceImageItem(
                        uri = uri,
                        onRemove = { 
                            val index = evidenceImages.indexOf(uri)
                            if (index != -1) {
                                onRemoveImageEvidence(index)
                            }
                        }
                    )
                }
            }
        }
        
        if (evidenceText.isEmpty() && evidenceImages.isEmpty()) {
            Text(
                text = stringResource(R.string.report_evidence_placeholder),
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun EvidenceTextItem(
    text: String,
    onRemove: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WhAlertDimensions.spacing_12),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            
            IconButton(
                onClick = onRemove,
                modifier = Modifier.size(WhAlertDimensions.icon_size_24)
            ) {
                Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "Remove",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun EvidenceImageItem(
    uri: Uri,
    onRemove: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(WhAlertDimensions.image_size_80)
            .clip(RoundedCornerShape(WhAlertDimensions.card_corner_radius_small))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        AsyncImage(
            model = uri,
            contentDescription = "Evidence",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        
        IconButton(
            onClick = onRemove,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(WhAlertDimensions.icon_size_20)
        ) {
            Box(
                modifier = Modifier
                    .size(WhAlertDimensions.icon_size_16)
                    .background(
                        MaterialTheme.colorScheme.error,
                        RoundedCornerShape(50)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "Remove",
                    tint = Color.White,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_12)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun NewReportScreenPreview() {
    WhAlertTheme {
        // Preview content
    }
}

// Preview for Theme
@Preview(showBackground = true)
@Composable
private fun ThemePreview() {
    WhAlertTheme {
        Surface {
            Text("Preview")
        }
    }
}
