package com.whalert.app.presentation.screens.report

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.whalert.app.R
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.model.ReportStatus
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.ReportDetailViewModel
import com.whalert.app.util.Constants
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel
import java.util.Date

@Composable
fun ReportDetailScreen(
    reportId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val viewModel: ReportDetailViewModel = koinViewModel()
    val state = viewModel.state.collectAsStateWithLifecycle().value
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val clipboardManager = LocalClipboardManager.current
    
    var showMenu by remember { mutableStateOf(false) }
    
    LaunchedEffect(reportId) {
        viewModel.loadReport(reportId)
    }
    
    LaunchedEffect(state.reportDeleted) {
        if (state.reportDeleted) {
            onDelete()
            viewModel.resetState()
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Report Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More options"
                        )
                    }
                    
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Copy Report ID") },
                            onClick = {
                                state.report?.id?.let { id ->
                                    clipboardManager.setText(AnnotatedString(id))
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Report ID copied")
                                    }
                                }
                                showMenu = false
                            },
                            leadingIcon = {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                            }
                        )
                        
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            onClick = {
                                onEdit()
                                showMenu = false
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Edit, contentDescription = null)
                            }
                        )
                        
                        DropdownMenuItem(
                            text = { Text("Delete") },
                            onClick = {
                                viewModel.deleteReport(reportId)
                                showMenu = false
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Delete, contentDescription = null)
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            if (state.isLoading && state.report == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(WhAlertDimensions.spacing_32),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (state.report == null) {
                ErrorState(
                    message = state.error ?: "Report not found",
                    onRetry = { viewModel.loadReport(reportId) }
                )
            } else {
                ReportContent(
                    report = state.report!!,
                    onSubmit = { viewModel.submitReport(reportId) },
                    onDelete = { viewModel.deleteReport(reportId) }
                )
            }
        }
    }
}

@Composable
private fun ErrorState(
    message: String,
    onRetry: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WhAlertDimensions.spacing_32),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = WhAlertColors.StatusError,
            modifier = Modifier.size(WhAlertDimensions.icon_size_48)
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        Text(
            text = "Error",
            style = WhAlertTypography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = message,
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        Button(
            onClick = onRetry,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Text("Retry")
        }
    }
}

@Composable
private fun ReportContent(
    report: Report,
    onSubmit: () -> Unit,
    onDelete: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(WhAlertDimensions.spacing_16)
    ) {
        // Status Banner
        if (report.isSubmitted()) {
            SubmittedBanner()
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        }
        
        // Report Card
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = WhAlertDimensions.card_elevation
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(WhAlertDimensions.spacing_16)
            ) {
                // Report ID
                ReportField(
                    label = "Report ID",
                    value = report.id,
                    icon = Icons.Default.Info
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                Divider()
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                
                // Phone Number
                ReportField(
                    label = "Phone Number",
                    value = report.getFullPhoneNumber(),
                    icon = Icons.Default.ArrowForward
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                
                // Category
                ReportField(
                    label = "Category",
                    value = report.category.getDisplayName(),
                    icon = getCategoryIcon(report.category)
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                Divider()
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                
                // Description
                Text(
                    text = "Description",
                    style = WhAlertTypography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
                
                Text(
                    text = report.description,
                    style = WhAlertTypography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                Divider()
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                
                // Date and Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_16)
                ) {
                    ReportField(
                        label = "Date",
                        value = report.getFormattedDate(),
                        icon = Icons.Default.CalendarToday,
                        modifier = Modifier.weight(1f)
                    )
                    
                    ReportField(
                        label = "Time",
                        value = report.getFormattedTime(),
                        icon = Icons.Default.Schedule,
                        modifier = Modifier.weight(1f)
                    )
                }
                
                if (report.hasEvidence()) {
                    Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                    Divider()
                    Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                    
                    // Evidence Section
                    Text(
                        text = "Evidence (${report.getEvidenceCount()})",
                        style = WhAlertTypography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
                    
                    // Text Evidence
                    report.evidenceText?.let { textList ->
                        if (textList.isNotEmpty()) {
                            Text(
                                text = "Text Evidence",
                                style = WhAlertTypography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_4))
                            
                            textList.forEachIndexed { index, text ->
                                Text(
                                    text = "${index + 1}. $text",
                                    style = WhAlertTypography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(vertical = WhAlertDimensions.spacing_4)
                                )
                            }
                        }
                    }
                    
                    // Image Evidence
                    report.evidenceImagePaths?.let { imagePaths ->
                        if (imagePaths.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
                            Text(
                                text = "Image Evidence",
                                style = WhAlertTypography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_4))
                            
                            // Placeholder for image evidence
                            Text(
                                text = "${imagePaths.size} image(s) attached",
                                style = WhAlertTypography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                Divider()
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_12))
                
                // Status and Dates
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatusBadge(status = report.status)
                    
                    Text(
                        text = "Created: ${report.createdAt}",
                        style = WhAlertTypography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        // Actions
        if (!report.isSubmitted()) {
            Button(
                onClick = onSubmit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(WhAlertDimensions.button_height_large),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(WhAlertDimensions.button_corner_radius_large)
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_20)
                )
                Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_8))
                Text(
                    text = "Submit Report",
                    style = WhAlertTypography.labelLarge
                )
            }
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        // Disclaimer
        Text(
            text = stringResource(R.string.report_disclaimer),
            style = WhAlertTypography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ReportField(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(WhAlertDimensions.icon_size_18)
        )
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = label,
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Text(
                text = value,
                style = WhAlertTypography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun getCategoryIcon(category: ReportCategory): androidx.compose.ui.graphics.vector.ImageVector {
    return when (category) {
        ReportCategory.SPAM -> Icons.Default.Info
        ReportCategory.SCAMS -> Icons.Default.ArrowForward
        ReportCategory.IMPERSONATION -> Icons.Default.Info
        ReportCategory.HARASSMENT -> Icons.Default.Info
        ReportCategory.FRAUDULENT_CONTENT -> Icons.Default.Info
        ReportCategory.MALICIOUS_BEHAVIOR -> Icons.Default.Info
        ReportCategory.OTHER -> Icons.Default.Info
    }
}

@Composable
private fun StatusBadge(status: ReportStatus) {
    val color = when (status) {
        ReportStatus.DRAFT -> WhAlertColors.StatusPending
        ReportStatus.PREPARED -> WhAlertColors.StatusProcessing
        ReportStatus.SUBMITTED -> WhAlertColors.StatusSuccess
        ReportStatus.CONFIRMATION_RECEIVED -> WhAlertColors.StatusSuccess
        ReportStatus.FOLLOW_UP_NEEDED -> WhAlertColors.StatusWarning
        ReportStatus.CLOSED -> WhAlertColors.StatusCancelled
    }
    
    val textColor = when (status) {
        ReportStatus.DRAFT,
        ReportStatus.PREPARED,
        ReportStatus.FOLLOW_UP_NEEDED,
        ReportStatus.CLOSED -> Color.White
        else -> Color.White
    }
    
    Box(
        modifier = Modifier
            .background(color, RoundedCornerShape(WhAlertDimensions.badge_corner_radius))
            .padding(horizontal = WhAlertDimensions.spacing_12, vertical = WhAlertDimensions.spacing_6)
    ) {
        Text(
            text = status.getDisplayName(),
            style = WhAlertTypography.bodySmall,
            color = textColor
        )
    }
}

@Composable
private fun SubmittedBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(WhAlertColors.StatusSuccessContainer)
            .padding(WhAlertDimensions.spacing_12),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacing(WhAlertDimensions.spacing_8)
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = WhAlertColors.StatusSuccess
            )
            
            Text(
                text = stringResource(R.string.report_status_sent_from_app),
                style = WhAlertTypography.bodySmall,
                color = WhAlertColors.StatusSuccess
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ReportDetailScreenPreview() {
    val previewReport = Report(
        id = "12345",
        userId = "user1",
        phoneNumber = "1234567890",
        countryCode = "+1",
        category = ReportCategory.SCAMS,
        description = "This is a test report description for preview purposes.",
        date = Date(),
        time = "10:00 AM",
        evidenceText = listOf("Test evidence 1", "Test evidence 2"),
        evidenceImagePaths = listOf("path1", "path2"),
        status = ReportStatus.SUBMITTED
    )
    
    WhAlertTheme {
        ReportDetailScreen(
            reportId = "12345",
            onBack = {},
            onEdit = {},
            onDelete = {}
        )
    }
}

@Composable
fun WhAlertTheme(
    content: @Composable () -> Unit
) {
    // This is a placeholder for the actual theme
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(),
        content = content
    )
}
