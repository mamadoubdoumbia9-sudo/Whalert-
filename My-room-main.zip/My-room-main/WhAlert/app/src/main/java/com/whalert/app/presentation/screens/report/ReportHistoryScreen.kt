package com.whalert.app.presentation.screens.report

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.whalert.app.R
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportStatus
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.ReportHistoryViewModel
import com.whalert.app.util.Constants
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel

@Composable
fun ReportHistoryScreen(
    onBack: () -> Unit,
    onReportClick: (String) -> Unit,
    onNewReport: () -> Unit
) {
    val viewModel: ReportHistoryViewModel = koinViewModel()
    val state = viewModel.state.collectAsStateWithLifecycle().value
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    var searchQuery by rememberSaveable { mutableStateOf("") }
    
    LaunchedEffect(searchQuery) {
        viewModel.filterReports(searchQuery)
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.report_history_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            Button(
                onClick = onNewReport,
                modifier = Modifier
                    .padding(WhAlertDimensions.spacing_16),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(WhAlertDimensions.button_corner_radius_pill)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.action_new_report)
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search reports") },
                placeholder = { Text("Search by phone, description, or category") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(
                            onClick = { searchQuery = "" }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear"
                            )
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(WhAlertDimensions.spacing_16)
            )
            
            // Loading Indicator
            if (state.isLoading && state.reports.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(WhAlertDimensions.spacing_32),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (state.filteredReports.isEmpty()) {
                // Empty State
                EmptyState(
                    title = stringResource(R.string.report_history_empty),
                    description = stringResource(R.string.report_history_empty_description),
                    onNewReport = onNewReport
                )
            } else {
                // Reports List
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.filteredReports) { report ->
                        ReportItem(
                            report = report,
                            onClick = { onReportClick(report.id) },
                            onDelete = {
                                coroutineScope.launch {
                                    viewModel.deleteReport(report.id)
                                    snackbarHostState.showSnackbar("Report deleted")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(
    title: String,
    description: String,
    onNewReport: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WhAlertDimensions.spacing_32),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.DateRange,
                contentDescription = null,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        Text(
            text = title,
            style = WhAlertTypography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = description,
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
        
        Button(
            onClick = onNewReport,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Text(stringResource(R.string.action_new_report))
        }
    }
}

@Composable
private fun ReportItem(
    report: Report,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(WhAlertDimensions.spacing_12),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = WhAlertDimensions.card_elevation
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WhAlertDimensions.spacing_16)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = report.getFullPhoneNumber(),
                        style = WhAlertTypography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_4))
                    
                    Text(
                        text = report.category.getDisplayName(),
                        style = WhAlertTypography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                StatusBadge(status = report.status)
            }
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            
            Text(
                text = report.description.take(100) + if (report.description.length > 100) "..." else "",
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = report.getFormattedDate(),
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                IconButton(
                    onClick = { onDelete() },
                    modifier = Modifier.size(WhAlertDimensions.icon_size_24)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: ReportStatus) {
    val color = when (status) {
        ReportStatus.DRAFT -> WhAlertColors.StatusPending
        ReportStatus.PREPARED -> WhAlertColors.StatusProcessing
        ReportStatus.SUBMITTED -> WhAlertColors.StatusProcessing
        ReportStatus.CONFIRMATION_RECEIVED -> WhAlertColors.StatusSuccess
        ReportStatus.FOLLOW_UP_NEEDED -> WhAlertColors.StatusWarning
        ReportStatus.CLOSED -> WhAlertColors.StatusCancelled
    }
    
    Box(
        modifier = Modifier
            .background(color, RoundedCornerShape(WhAlertDimensions.badge_corner_radius))
            .padding(horizontal = WhAlertDimensions.spacing_8, vertical = WhAlertDimensions.spacing_4)
    ) {
        Text(
            text = status.getDisplayName(),
            style = WhAlertTypography.bodySmall,
            color = Color.White
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ReportHistoryScreenPreview() {
    WhAlertTheme {
        ReportHistoryScreen(
            onBack = {},
            onReportClick = {},
            onNewReport = {}
        )
    }
}

@Composable
fun WhAlertTheme(
    content: @Composable () -> Unit
) {
    // This is a placeholder for the actual theme
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(),
        content = content
    )
}
