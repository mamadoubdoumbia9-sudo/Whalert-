package com.whalert.app.presentation.screens.report


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.whalert.app.R
import com.whalert.app.domain.model.ReportStatus
import com.whalert.app.presentation.theme.WhAlertTheme
import com.whalert.app.presentation.viewmodel.ReportDetailViewModel
import org.koin.androidx.compose.koinViewModel

/**
 * Report Status Screen
 * Shows the status of a submitted report
 */
@Composable
fun ReportStatusScreen(
    reportId: String,
    onBack: () -> Unit,
    onViewDetail: () -> Unit,
    navController: NavController? = null
) {
    val viewModel: ReportDetailViewModel = koinViewModel()
    val report by viewModel.getReportById(reportId).observeAsState(null)
    
    LaunchedEffect(reportId) {
        viewModel.loadReport(reportId)
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.report_status_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Text(
                    text = stringResource(R.string.report_status_subtitle),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 16.dp)
                )
                
                // Status Timeline
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.report_status_timeline),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Divider(color = MaterialTheme.colorScheme.outlineVariant)
                        
                        report?.let { reportData ->
                            // Timeline Steps
                            TimelineStep(
                                icon = Icons.Default.Send,
                                title = stringResource(R.string.report_status_sent_from_app),
                                description = stringResource(R.string.report_status_sent_from_app_desc),
                                isCompleted = true,
                                isCurrent = reportData.status == ReportStatus.DRAFT || reportData.status == ReportStatus.PREPARED
                            )
                            
                            TimelineStep(
                                icon = Icons.Default.CheckCircle,
                                title = stringResource(R.string.report_status_transmitted_to_official),
                                description = stringResource(R.string.report_status_transmitted_desc),
                                isCompleted = reportData.status == ReportStatus.SUBMITTED || 
                                        reportData.status == ReportStatus.CONFIRMATION_RECEIVED ||
                                        reportData.status == ReportStatus.FOLLOW_UP_NEEDED ||
                                        reportData.status == ReportStatus.CLOSED,
                                isCurrent = reportData.status == ReportStatus.SUBMITTED
                            )
                            
                            TimelineStep(
                                icon = Icons.Default.Pending,
                                title = stringResource(R.string.report_status_confirmation_received),
                                description = stringResource(R.string.report_status_confirmation_desc),
                                isCompleted = reportData.status == ReportStatus.CONFIRMATION_RECEIVED ||
                                        reportData.status == ReportStatus.FOLLOW_UP_NEEDED ||
                                        reportData.status == ReportStatus.CLOSED,
                                isCurrent = reportData.status == ReportStatus.CONFIRMATION_RECEIVED
                            )
                            
                            TimelineStep(
                                icon = Icons.Default.History,
                                title = stringResource(R.string.report_status_follow_up_needed),
                                description = stringResource(R.string.report_status_follow_up_desc),
                                isCompleted = reportData.status == ReportStatus.FOLLOW_UP_NEEDED ||
                                        reportData.status == ReportStatus.CLOSED,
                                isCurrent = reportData.status == ReportStatus.FOLLOW_UP_NEEDED
                            )
                            
                            TimelineStep(
                                icon = Icons.Default.QuestionMark,
                                title = stringResource(R.string.report_status_whatsapp_decision_unknown),
                                description = stringResource(R.string.report_status_decision_unknown_desc),
                                isCompleted = false,
                                isCurrent = reportData.status == ReportStatus.CLOSED
                            )
                        } ?: run {
                            // Loading state
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = stringResource(R.string.loading),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                
                // Status Card
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = when (report?.status) {
                            ReportStatus.CLOSED -> MaterialTheme.colorScheme.errorContainer
                            ReportStatus.CONFIRMATION_RECEIVED -> MaterialTheme.colorScheme.tertiaryContainer
                            ReportStatus.SUBMITTED -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceContainer
                        },
                        contentColor = when (report?.status) {
                            ReportStatus.CLOSED -> MaterialTheme.colorScheme.onErrorContainer
                            ReportStatus.CONFIRMATION_RECEIVED -> MaterialTheme.colorScheme.onTertiaryContainer
                            ReportStatus.SUBMITTED -> MaterialTheme.colorScheme.onPrimaryContainer
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        report?.let { reportData ->
                            Icon(
                                imageVector = when (reportData.status) {
                                    ReportStatus.CLOSED -> Icons.Default.CheckCircle
                                    ReportStatus.CONFIRMATION_RECEIVED -> Icons.Default.CheckCircle
                                    ReportStatus.SUBMITTED -> Icons.Default.Send
                                    ReportStatus.FOLLOW_UP_NEEDED -> Icons.Default.Pending
                                    ReportStatus.PREPARED -> Icons.Default.Pending
                                    ReportStatus.DRAFT -> Icons.Default.Info
                                },
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = when (reportData.status) {
                                    ReportStatus.CLOSED -> MaterialTheme.colorScheme.onErrorContainer
                                    ReportStatus.CONFIRMATION_RECEIVED -> MaterialTheme.colorScheme.onTertiaryContainer
                                    ReportStatus.SUBMITTED -> MaterialTheme.colorScheme.onPrimaryContainer
                                    else -> MaterialTheme.colorScheme.onSurface
                                }
                            )
                            
                            Text(
                                text = reportData.status.displayName,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Text(
                                text = stringResource(R.string.report_status_description, reportData.status.displayName),
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                        } ?: run {
                            Text(
                                text = stringResource(R.string.loading),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
                
                // Important Notice
                ElevatedCard(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = stringResource(R.string.report_status_whatsapp_disclaimer),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = stringResource(R.string.report_status_no_confirmation),
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Action Buttons
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = onViewDetail,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.view_details),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    
                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.back),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun TimelineStep(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    isCompleted: Boolean,
    isCurrent: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Status indicator
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(50))
                .background(
                    when {
                        isCompleted -> MaterialTheme.colorScheme.primary
                        isCurrent -> MaterialTheme.colorScheme.primaryContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
                tint = when {
                    isCompleted -> MaterialTheme.colorScheme.onPrimary
                    isCurrent -> MaterialTheme.colorScheme.onPrimaryContainer
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
            )
        }
        
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (isCompleted || isCurrent) FontWeight.Bold else FontWeight.Normal
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        // Connector line (for all but last)
        if (!isCurrent && !isCompleted) {
            Box(
                modifier = Modifier
                    .height(2.dp)
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ReportStatusScreenPreview() {
    WhAlertTheme {
        ReportStatusScreen(
            reportId = "1",
            onBack = {},
            onViewDetail = {}
        )
    }
}
