package com.whalert.app.presentation.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.whalert.app.R
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.SettingsViewModel
import com.whalert.app.util.Constants
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val viewModel: SettingsViewModel = koinViewModel()
    val state = viewModel.state.collectAsStateWithLifecycle().value
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    var selectedTheme by rememberSaveable { mutableStateOf(state.theme) }
    var notificationsEnabled by rememberSaveable { mutableStateOf(state.notificationsEnabled) }
    var notificationsSound by rememberSaveable { mutableStateOf(state.notificationsSound) }
    var notificationsVibrate by rememberSaveable { mutableStateOf(state.notificationsVibrate) }
    var biometricEnabled by rememberSaveable { mutableStateOf(state.biometricEnabled) }
    var dailyLimit by rememberSaveable { mutableStateOf(state.dailyLimit) }
    
    LaunchedEffect(state) {
        selectedTheme = state.theme
        notificationsEnabled = state.notificationsEnabled
        notificationsSound = state.notificationsSound
        notificationsVibrate = state.notificationsVibrate
        biometricEnabled = state.biometricEnabled
        dailyLimit = state.dailyLimit
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
            
            // Header
            SettingsHeader()
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
            
            // Settings Sections
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = WhAlertDimensions.spacing_16)
            ) {
                // Appearance Section
                SettingsSection(
                    title = stringResource(R.string.settings_section_appearance)
                ) {
                    // Theme
                    SettingItem(
                        title = stringResource(R.string.settings_appearance_theme),
                        description = selectedTheme.replaceFirstChar { it.uppercase() },
                        icon = Icons.Default.Palette,
                        onClick = { /* Show theme dialog */ }
                    )
                }
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Notifications Section
                SettingsSection(
                    title = stringResource(R.string.settings_section_notifications)
                ) {
                    // Enable Notifications
                    SwitchSettingItem(
                        title = stringResource(R.string.settings_notifications_enable),
                        icon = Icons.Default.Notifications,
                        isChecked = notificationsEnabled,
                        onCheckedChange = { checked ->
                            notificationsEnabled = checked
                            viewModel.setNotificationsEnabled(checked)
                        }
                    )
                    
                    // Notification Sound
                    SwitchSettingItem(
                        title = stringResource(R.string.settings_notifications_sound),
                        icon = Icons.Default.VolumeUp,
                        isChecked = notificationsSound,
                        onCheckedChange = { checked ->
                            notificationsSound = checked
                            viewModel.setNotificationsSound(checked)
                        }
                    )
                    
                    // Vibrate
                    SwitchSettingItem(
                        title = stringResource(R.string.settings_notifications_vibrate),
                        icon = Icons.Default.Vibration,
                        isChecked = notificationsVibrate,
                        onCheckedChange = { checked ->
                            notificationsVibrate = checked
                            viewModel.setNotificationsVibrate(checked)
                        }
                    )
                }
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // Security Section
                SettingsSection(
                    title = stringResource(R.string.settings_section_security)
                ) {
                    // Biometric Authentication
                    SwitchSettingItem(
                        title = stringResource(R.string.settings_security_biometric),
                        description = stringResource(R.string.settings_security_biometric_description),
                        icon = Icons.Default.Biotech,
                        isChecked = biometricEnabled,
                        onCheckedChange = { checked ->
                            biometricEnabled = checked
                            viewModel.setBiometricEnabled(checked)
                        }
                    )
                    
                    // Daily Report Limit
                    SettingItem(
                        title = stringResource(R.string.settings_security_daily_limit),
                        description = stringResource(R.string.settings_security_daily_limit_description),
                        icon = Icons.Default.Security,
                        onClick = { /* Show limit dialog */ }
                    )
                }
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
                
                // About Section
                SettingsSection(
                    title = stringResource(R.string.settings_section_about)
                ) {
                    // Version
                    SettingItem(
                        title = stringResource(R.string.settings_about_version, Constants.APP_VERSION),
                        icon = Icons.Default.Info,
                        onClick = { /* Show version info */ }
                    )
                    
                    // Privacy Policy
                    SettingItem(
                        title = stringResource(R.string.settings_about_privacy_policy),
                        icon = Icons.Default.Security,
                        onClick = { /* Open privacy policy */ }
                    )
                    
                    // Terms of Service
                    SettingItem(
                        title = stringResource(R.string.settings_about_terms_of_service),
                        icon = Icons.Default.Info,
                        onClick = { /* Open terms of service */ }
                    )
                    
                    // Open Source Licenses
                    SettingItem(
                        title = stringResource(R.string.settings_about_open_source),
                        icon = Icons.Default.Info,
                        onClick = { /* Open open source licenses */ }
                    )
                }
                
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
                
                // Logout Button
                ElevatedCard(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(WhAlertDimensions.spacing_16),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = stringResource(R.string.action_logout),
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(WhAlertDimensions.icon_size_24)
                        )
                        
                        Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
                        
                        Text(
                            text = stringResource(R.string.action_logout),
                            style = WhAlertTypography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        }
    }
}

@Composable
private fun SettingsHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        Text(
            text = stringResource(R.string.settings_title),
            style = WhAlertTypography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = stringResource(R.string.settings_subtitle),
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = Alignment.Center
        )
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = title,
            style = WhAlertTypography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = WhAlertDimensions.card_elevation
            )
        ) {
            content()
        }
    }
}

@Composable
private fun SettingItem(
    title: String,
    description: String? = null,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onClick()
            }
            .padding(WhAlertDimensions.spacing_16),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(WhAlertDimensions.icon_size_24)
        )
        
        Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = WhAlertTypography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            description?.let {
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_2))
                Text(
                    text = it,
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .size(WhAlertDimensions.icon_size_20)
                .rotate(180f)
        )
    }
}

@Composable
private fun SwitchSettingItem(
    title: String,
    description: String? = null,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(WhAlertDimensions.spacing_16),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(WhAlertDimensions.icon_size_24)
        )
        
        Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = WhAlertTypography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            description?.let {
                Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_2))
                Text(
                    text = it,
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsScreenPreview() {
    WhAlertTheme {
        SettingsScreen(
            onBack = {},
            onLogout = {}
        )
    }
}

@Composable
fun WhAlertTheme(
    content: @Composable () -> Unit
) {
    // This is a placeholder for the actual theme
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(),
        content = content
    )
}

val CardDefaults = androidx.compose.material3.CardDefaults
