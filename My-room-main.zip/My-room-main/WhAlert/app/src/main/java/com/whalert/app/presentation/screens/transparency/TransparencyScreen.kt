package com.whalert.app.presentation.screens.transparency

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.whalert.app.R
import com.whalert.app.presentation.theme.WhAlertColors
import com.whalert.app.presentation.theme.WhAlertDimensions
import com.whalert.app.presentation.theme.WhAlertTypography
import com.whalert.app.presentation.viewmodel.TransparencyViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun TransparencyScreen(onBack: () -> Unit) {
    val viewModel: TransparencyViewModel = koinViewModel()
    val canDoItems = viewModel.getCanDoItems()
    val cannotDoItems = viewModel.getCannotDoItems()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.transparency_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
            
            // Header
            TransparencyHeader()
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
            
            // What WhAlert CAN do
            SectionTitle(
                title = stringResource(R.string.transparency_section_can),
                modifier = Modifier.padding(horizontal = WhAlertDimensions.spacing_16)
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(canDoItems) { (title, description) ->
                    TransparencyItem(
                        title = title,
                        description = description,
                        isCanDo = true,
                        modifier = Modifier.padding(WhAlertDimensions.spacing_12)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_24))
            
            // What WhAlert CANNOT do
            SectionTitle(
                title = stringResource(R.string.transparency_section_cannot),
                modifier = Modifier.padding(horizontal = WhAlertDimensions.spacing_16)
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
            
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(cannotDoItems) { (title, description) ->
                    TransparencyItem(
                        title = title,
                        description = description,
                        isCanDo = false,
                        modifier = Modifier.padding(WhAlertDimensions.spacing_12)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
            
            // Note
            Text(
                text = stringResource(R.string.transparency_note),
                style = WhAlertTypography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(WhAlertDimensions.spacing_16)
            )
            
            Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        }
    }
}

@Composable
private fun TransparencyHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = WhAlertDimensions.spacing_16),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(WhAlertDimensions.app_logo_size)
                .background(
                    WhAlertColors.PrimaryContainer,
                    RoundedCornerShape(WhAlertDimensions.card_corner_radius_large)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = WhAlertColors.Primary,
                modifier = Modifier.size(WhAlertDimensions.app_logo_size_small)
            )
        }
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_16))
        
        Text(
            text = stringResource(R.string.transparency_title),
            style = WhAlertTypography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(WhAlertDimensions.spacing_8))
        
        Text(
            text = stringResource(R.string.transparency_subtitle),
            style = WhAlertTypography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SectionTitle(
    title: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = title,
        style = WhAlertTypography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
        fontWeight = FontWeight.Bold,
        modifier = modifier
    )
}

@Composable
private fun TransparencyItem(
    title: String,
    description: String,
    isCanDo: Boolean,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = WhAlertDimensions.card_elevation
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WhAlertDimensions.spacing_16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(WhAlertDimensions.icon_size_24)
                    .background(
                        if (isCanDo) WhAlertColors.StatusSuccess else WhAlertColors.StatusError,
                        RoundedCornerShape(50)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isCanDo) Icons.Default.Check else Icons.Default.Close,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(WhAlertDimensions.icon_size_16)
                )
            }
            
            Spacer(modifier = Modifier.width(WhAlertDimensions.spacing_12))
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = WhAlertTypography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = description,
                    style = WhAlertTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TransparencyScreenPreview() {
    WhAlertTheme {
        TransparencyScreen(onBack = {})
    }
}

@Composable
fun WhAlertTheme(
    content: @Composable () -> Unit
) {
    // This is a placeholder for the actual theme
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(),
        content = content
    )
}

val CardDefaults = androidx.compose.material3.CardDefaults
