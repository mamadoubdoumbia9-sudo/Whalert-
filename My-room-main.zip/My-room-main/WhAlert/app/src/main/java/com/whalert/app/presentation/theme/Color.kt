package com.whalert.app.presentation.theme

import androidx.compose.ui.graphics.Color

object WhAlertColors {
    // Primary Colors
    val Primary = Color(0xFF625BFF)
    val PrimaryContainer = Color(0xFFEADDFF)
    val OnPrimary = Color(0xFFFFFFFF)
    val OnPrimaryContainer = Color(0xFF1D1965)
    val PrimaryInverse = Color(0xFFD9D6FF)
    
    // Secondary Colors
    val Secondary = Color(0xFF605D66)
    val SecondaryContainer = Color(0xFFE7E1EC)
    val OnSecondary = Color(0xFFFFFFFF)
    val OnSecondaryContainer = Color(0xFF1D1A22)
    
    // Tertiary Colors
    val Tertiary = Color(0xFF7E5260)
    val TertiaryContainer = Color(0xFFFFD9E2)
    val OnTertiary = Color(0xFFFFFFFF)
    val OnTertiaryContainer = Color(0xFF31111D)
    
    // Error Colors
    val Error = Color(0xFFB3261E)
    val ErrorContainer = Color(0xFFF9DEDC)
    val OnError = Color(0xFFFFFFFF)
    val OnErrorContainer = Color(0xFF410E0B)
    
    // Background Colors
    val Background = Color(0xFFFFF8F7)
    val OnBackground = Color(0xFF1D1B20)
    
    // Surface Colors
    val Surface = Color(0xFFFFF8F7)
    val SurfaceVariant = Color(0xFFECE6F0)
    val OnSurface = Color(0xFF1D1B20)
    val OnSurfaceVariant = Color(0xFF49454F)
    
    // Outline Colors
    val Outline = Color(0xFF79747E)
    val OutlineVariant = Color(0xFFCAC4D0)
    
    // Shadow Colors
    val Shadow = Color(0xFF000000)
    
    // Scrim Colors
    val Scrim = Color(0xFF000000)
    
    // Inverse Colors
    val InverseSurface = Color(0xFF322F35)
    val InverseOnSurface = Color(0xFFF5EFF7)
    
    // Semantic Colors
    val Success = Color(0xFF10B981)
    val SuccessContainer = Color(0xFFD1FAE5)
    val OnSuccess = Color(0xFFFFFFFF)
    val OnSuccessContainer = Color(0xFF065F46)
    
    val Warning = Color(0xFFF59E0B)
    val WarningContainer = Color(0xFFFEF3C7)
    val OnWarning = Color(0xFFFFFFFF)
    val OnWarningContainer = Color(0xFF92400E)
    
    val Info = Color(0xFF3B82F6)
    val InfoContainer = Color(0xFFDBEAFE)
    val OnInfo = Color(0xFFFFFFFF)
    val OnInfoContainer = Color(0xFF1E40AF)
    
    // App Specific Colors
    val AppPrimary = Color(0xFF625BFF)
    val AppPrimaryDark = Color(0xFF4A44D6)
    val AppPrimaryLight = Color(0xFF8A85FF)
    val AppSecondary = Color(0xFF7C3AED)
    val AppAccent = Color(0xFFEC4899)
    val AppBackground = Color(0xFFF8F9FA)
    val AppSurface = Color(0xFFFFFFFF)
    val AppError = Color(0xFFEF4444)
    val AppSuccess = Color(0xFF10B981)
    val AppWarning = Color(0xFFF59E0B)
    val AppInfo = Color(0xFF3B82F6)
    
    // Text Colors
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val TextTertiary = Color(0xFF9CA3AF)
    val TextInverse = Color(0xFFFFFFFF)
    val TextLink = Color(0xFF625BFF)
    
    // Button Colors
    val ButtonPrimary = Color(0xFF625BFF)
    val ButtonPrimaryDisabled = Color(0xFFA5B4FC)
    val ButtonSecondary = Color(0xFFF3F4F6)
    val ButtonSecondaryText = Color(0xFF374151)
    val ButtonOutline = Color(0xFFD1D5DB)
    val ButtonDanger = Color(0xFFEF4444)
    val ButtonDangerText = Color(0xFFFFFFFF)
    
    // Card Colors
    val CardBackground = Color(0xFFFFFFFF)
    val CardStroke = Color(0xFFE5E7EB)
    val CardShadow = Color(0x1A000000)
    
    // Divider Colors
    val Divider = Color(0xFFE5E7EB)
    
    // Status Colors
    val StatusPending = Color(0xFFF59E0B)
    val StatusProcessing = Color(0xFF3B82F6)
    val StatusSuccess = Color(0xFF10B981)
    val StatusError = Color(0xFFEF4444)
    val StatusCancelled = Color(0xFF6B7280)
    
    // Gradient Colors
    val GradientStart = Color(0xFF625BFF)
    val GradientEnd = Color(0xFF7C3AED)
    val GradientSecondaryStart = Color(0xFFEC4899)
    val GradientSecondaryEnd = Color(0xFF8B5CF6)
    
    // Overlay Colors
    val OverlayDark = Color(0x80000000)
    val OverlayLight = Color(0x80FFFFFF)
    
    // Transparent Colors
    val Transparent = Color(0x00000000)
    val SemiTransparent = Color(0x80000000)
}
