package com.whalert.app.presentation.theme

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object WhAlertDimensions {
    // Spacing System
    val spacing_0: Dp = 0.dp
    val spacing_1: Dp = 1.dp
    val spacing_2: Dp = 2.dp
    val spacing_3: Dp = 3.dp
    val spacing_4: Dp = 4.dp
    val spacing_5: Dp = 5.dp
    val spacing_6: Dp = 6.dp
    val spacing_7: Dp = 7.dp
    val spacing_8: Dp = 8.dp
    val spacing_9: Dp = 9.dp
    val spacing_10: Dp = 10.dp
    val spacing_11: Dp = 11.dp
    val spacing_12: Dp = 12.dp
    val spacing_13: Dp = 13.dp
    val spacing_14: Dp = 14.dp
    val spacing_15: Dp = 15.dp
    val spacing_16: Dp = 16.dp
    val spacing_17: Dp = 17.dp
    val spacing_18: Dp = 18.dp
    val spacing_19: Dp = 19.dp
    val spacing_20: Dp = 20.dp
    val spacing_24: Dp = 24.dp
    val spacing_28: Dp = 28.dp
    val spacing_32: Dp = 32.dp
    val spacing_36: Dp = 36.dp
    val spacing_40: Dp = 40.dp
    val spacing_44: Dp = 44.dp
    val spacing_48: Dp = 48.dp
    val spacing_52: Dp = 52.dp
    val spacing_56: Dp = 56.dp
    val spacing_60: Dp = 60.dp
    val spacing_64: Dp = 64.dp
    val spacing_72: Dp = 72.dp
    val spacing_80: Dp = 80.dp
    val spacing_88: Dp = 88.dp
    val spacing_96: Dp = 96.dp
    val spacing_100: Dp = 100.dp

    // Margin System
    val margin_0: Dp = 0.dp
    val margin_4: Dp = 4.dp
    val margin_8: Dp = 8.dp
    val margin_12: Dp = 12.dp
    val margin_16: Dp = 16.dp
    val margin_20: Dp = 20.dp
    val margin_24: Dp = 24.dp
    val margin_28: Dp = 28.dp
    val margin_32: Dp = 32.dp

    // Padding System
    val padding_0: Dp = 0.dp
    val padding_4: Dp = 4.dp
    val padding_8: Dp = 8.dp
    val padding_12: Dp = 12.dp
    val padding_16: Dp = 16.dp
    val padding_20: Dp = 20.dp
    val padding_24: Dp = 24.dp
    val padding_28: Dp = 28.dp
    val padding_32: Dp = 32.dp

    // Button Dimensions
    val button_height: Dp = 48.dp
    val button_height_small: Dp = 40.dp
    val button_height_large: Dp = 56.dp
    val button_min_width: Dp = 88.dp
    val button_min_width_small: Dp = 64.dp
    val button_min_width_large: Dp = 120.dp
    val button_corner_radius: Dp = 8.dp
    val button_corner_radius_small: Dp = 4.dp
    val button_corner_radius_large: Dp = 12.dp
    val button_corner_radius_pill: Dp = 24.dp

    // Card Dimensions
    val card_corner_radius: Dp = 12.dp
    val card_corner_radius_small: Dp = 8.dp
    val card_corner_radius_large: Dp = 16.dp
    val card_elevation: Dp = 2.dp
    val card_elevation_hovered: Dp = 4.dp
    val card_elevation_focused: Dp = 4.dp
    val card_stroke_width: Dp = 1.dp

    // TextField Dimensions
    val textfield_height: Dp = 56.dp
    val textfield_height_small: Dp = 48.dp
    val textfield_height_large: Dp = 64.dp
    val textfield_corner_radius: Dp = 8.dp
    val textfield_stroke_width: Dp = 1.dp
    val textfield_stroke_width_focused: Dp = 2.dp
    val textfield_internal_padding_horizontal: Dp = 16.dp
    val textfield_internal_padding_vertical: Dp = 12.dp

    // Icon Dimensions
    val icon_size_16: Dp = 16.dp
    val icon_size_18: Dp = 18.dp
    val icon_size_20: Dp = 20.dp
    val icon_size_24: Dp = 24.dp
    val icon_size_28: Dp = 28.dp
    val icon_size_32: Dp = 32.dp
    val icon_size_36: Dp = 36.dp
    val icon_size_40: Dp = 40.dp
    val icon_size_48: Dp = 48.dp
    val icon_size_56: Dp = 56.dp
    val icon_size_64: Dp = 64.dp

    // Image Dimensions
    val image_size_24: Dp = 24.dp
    val image_size_32: Dp = 32.dp
    val image_size_40: Dp = 40.dp
    val image_size_48: Dp = 48.dp
    val image_size_56: Dp = 56.dp
    val image_size_64: Dp = 64.dp
    val image_size_72: Dp = 72.dp
    val image_size_80: Dp = 80.dp
    val image_size_88: Dp = 88.dp
    val image_size_96: Dp = 96.dp

    // Avatar Dimensions
    val avatar_size_24: Dp = 24.dp
    val avatar_size_32: Dp = 32.dp
    val avatar_size_40: Dp = 40.dp
    val avatar_size_48: Dp = 48.dp
    val avatar_size_56: Dp = 56.dp
    val avatar_size_64: Dp = 64.dp
    val avatar_size_72: Dp = 72.dp
    val avatar_size_80: Dp = 80.dp

    // Divider Dimensions
    val divider_height: Dp = 1.dp
    val divider_height_thick: Dp = 2.dp

    // Progress Indicator Dimensions
    val progress_size: Dp = 24.dp
    val progress_size_small: Dp = 16.dp
    val progress_size_large: Dp = 32.dp
    val progress_stroke_width: Dp = 2.dp
    val progress_stroke_width_small: Dp = 1.5.dp
    val progress_stroke_width_large: Dp = 3.dp

    // Badge Dimensions
    val badge_size: Dp = 20.dp
    val badge_size_small: Dp = 16.dp
    val badge_size_large: Dp = 24.dp
    val badge_corner_radius: Dp = 10.dp
    val badge_corner_radius_small: Dp = 8.dp
    val badge_corner_radius_large: Dp = 12.dp

    // Chip Dimensions
    val chip_height: Dp = 32.dp
    val chip_height_small: Dp = 24.dp
    val chip_height_large: Dp = 40.dp
    val chip_corner_radius: Dp = 16.dp
    val chip_corner_radius_small: Dp = 12.dp
    val chip_corner_radius_large: Dp = 20.dp

    // Dialog Dimensions
    val dialog_corner_radius: Dp = 16.dp
    val dialog_corner_radius_small: Dp = 12.dp
    val dialog_corner_radius_large: Dp = 20.dp
    val dialog_max_width: Dp = 560.dp
    val dialog_max_width_small: Dp = 320.dp
    val dialog_max_width_large: Dp = 600.dp
    val dialog_elevation: Dp = 8.dp

    // Bottom Sheet Dimensions
    val bottom_sheet_corner_radius: Dp = 16.dp
    val bottom_sheet_corner_radius_small: Dp = 12.dp
    val bottom_sheet_corner_radius_large: Dp = 20.dp
    val bottom_sheet_elevation: Dp = 8.dp
    val bottom_sheet_peek_height: Dp = 100.dp
    val bottom_sheet_peek_height_small: Dp = 80.dp
    val bottom_sheet_peek_height_large: Dp = 120.dp

    // Top App Bar Dimensions
    val top_app_bar_height: Dp = 56.dp
    val top_app_bar_height_small: Dp = 48.dp
    val top_app_bar_height_large: Dp = 64.dp
    val top_app_bar_elevation: Dp = 0.dp
    val top_app_bar_elevation_scrolling: Dp = 4.dp

    // Bottom App Bar Dimensions
    val bottom_app_bar_height: Dp = 64.dp
    val bottom_app_bar_height_small: Dp = 56.dp
    val bottom_app_bar_height_large: Dp = 72.dp
    val bottom_app_bar_elevation: Dp = 8.dp

    // Navigation Bar Dimensions
    val navigation_bar_height: Dp = 56.dp
    val navigation_bar_height_small: Dp = 48.dp
    val navigation_bar_height_large: Dp = 64.dp

    // Floating Action Button Dimensions
    val fab_size: Dp = 56.dp
    val fab_size_small: Dp = 40.dp
    val fab_size_large: Dp = 64.dp
    val fab_elevation: Dp = 6.dp
    val fab_elevation_hovered: Dp = 8.dp
    val fab_elevation_focused: Dp = 8.dp

    // Snackbar Dimensions
    val snackbar_height: Dp = 48.dp
    val snackbar_height_small: Dp = 40.dp
    val snackbar_height_large: Dp = 56.dp
    val snackbar_corner_radius: Dp = 4.dp
    val snackbar_corner_radius_small: Dp = 2.dp
    val snackbar_corner_radius_large: Dp = 8.dp
    val snackbar_elevation: Dp = 6.dp

    // Tooltip Dimensions
    val tooltip_corner_radius: Dp = 4.dp
    val tooltip_elevation: Dp = 8.dp
    val tooltip_max_width: Dp = 280.dp

    // App Specific Dimensions
    val app_logo_size: Dp = 120.dp
    val app_logo_size_small: Dp = 80.dp
    val app_logo_size_large: Dp = 160.dp
    val app_header_height: Dp = 120.dp
    val app_header_height_small: Dp = 80.dp
    val app_header_height_large: Dp = 160.dp
    val app_footer_height: Dp = 60.dp
    val app_footer_height_small: Dp = 40.dp
    val app_footer_height_large: Dp = 80.dp

    // Report Form Dimensions
    val report_form_phone_field_height: Dp = 56.dp
    val report_form_category_chip_height: Dp = 40.dp
    val report_form_description_field_height: Dp = 120.dp
    val report_form_evidence_item_height: Dp = 80.dp

    // Status Timeline Dimensions
    val timeline_item_height: Dp = 72.dp
    val timeline_item_height_small: Dp = 64.dp
    val timeline_item_height_large: Dp = 80.dp
    val timeline_line_width: Dp = 2.dp
    val timeline_dot_size: Dp = 12.dp
    val timeline_dot_size_small: Dp = 8.dp
    val timeline_dot_size_large: Dp = 16.dp

    // Elevation Levels
    val elevation_level_0: Dp = 0.dp
    val elevation_level_1: Dp = 1.dp
    val elevation_level_2: Dp = 2.dp
    val elevation_level_3: Dp = 3.dp
    val elevation_level_4: Dp = 4.dp
    val elevation_level_5: Dp = 6.dp
    val elevation_level_6: Dp = 8.dp
    val elevation_level_7: Dp = 12.dp
    val elevation_level_8: Dp = 16.dp
}
