package com.whalert.app.presentation.theme

import android.app.Activity
nimport android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.util.VersionUtils
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = WhAlertColors.Primary,
    secondary = WhAlertColors.Secondary,
    tertiary = WhAlertColors.Tertiary,
    background = WhAlertColors.Background,
    surface = WhAlertColors.Surface,
    surfaceVariant = WhAlertColors.SurfaceVariant,
    onPrimary = WhAlertColors.OnPrimary,
    onSecondary = WhAlertColors.OnSecondary,
    onTertiary = WhAlertColors.OnTertiary,
    onBackground = WhAlertColors.OnBackground,
    onSurface = WhAlertColors.OnSurface,
    error = WhAlertColors.Error,
    onError = WhAlertColors.OnError
)

private val LightColorScheme = lightColorScheme(
    primary = WhAlertColors.Primary,
    secondary = WhAlertColors.Secondary,
    tertiary = WhAlertColors.Tertiary,
    background = WhAlertColors.Background,
    surface = WhAlertColors.Surface,
    surfaceVariant = WhAlertColors.SurfaceVariant,
    onPrimary = WhAlertColors.OnPrimary,
    onSecondary = WhAlertColors.OnSecondary,
    onTertiary = WhAlertColors.OnTertiary,
    onBackground = WhAlertColors.OnBackground,
    onSurface = WhAlertColors.OnSurface,
    error = WhAlertColors.Error,
    onError = WhAlertColors.OnError
)

@Composable
fun WhAlertTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    
    MaterialTheme(
        colorScheme = colorScheme,
        typography = WhAlertTypography,
        content = content
    )
}
