package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whalert.app.data.repository.ReportRepository
import com.whalert.app.domain.model.Report
import com.whalert.app.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Date

class AdminConsoleViewModel(
    private val reportRepository: ReportRepository
) : ViewModel() {
    
    private val _state = MutableStateFlow(AdminConsoleState())
    val state: StateFlow<AdminConsoleState> = _state.asStateFlow()
    
    init {
        loadStats()
    }
    
    fun loadStats() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            try {
                // Load total reports
                val totalReports = reportRepository.getAllReports()
                
                // Load recent reports
                val calendar = java.util.Calendar.getInstance()
                calendar.add(java.util.Calendar.DAY_OF_MONTH, -7)
                val startDate = calendar.time
                
                // These would be loaded from the repository
                // For now, we'll use placeholder values
                _state.value = _state.value.copy(
                    isLoading = false,
                    totalReports = 0, // Will be updated
                    reportsThisWeek = 0,
                    reportsToday = 0,
                    error = null
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message
                )
            }
        }
    }
    
    fun refresh() {
        loadStats()
    }
}

data class AdminConsoleState(
    val isLoading: Boolean = false,
    val totalReports: Int = 0,
    val reportsThisWeek: Int = 0,
    val reportsToday: Int = 0,
    val error: String? = null
)
