package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whalert.app.data.repository.AuthRepository
import com.whalert.app.domain.usecase.auth.GetCurrentUserUseCase
import com.whalert.app.domain.usecase.auth.LoginUseCase
import com.whalert.app.domain.usecase.auth.LogoutUseCase
import com.whalert.app.domain.usecase.auth.RegisterUseCase
import com.whalert.app.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
    private val loginUseCase: LoginUseCase,
    private val registerUseCase: RegisterUseCase,
    private val logoutUseCase: LogoutUseCase,
    private val getCurrentUserUseCase: GetCurrentUserUseCase
) : ViewModel() {
    
    private val _state = MutableStateFlow(AuthState())
    val state: StateFlow<AuthState> = _state.asStateFlow()
    
    init {
        checkCurrentUser()
    }
    
    fun login(email: String, password: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            val result = loginUseCase(email, password)
            
            when (result) {
                is Resource.Success -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        isLoggedIn = true,
                        userId = result.data?.uid,
                        error = null
                    )
                }
                is Resource.Error -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = result.message,
                        isLoggedIn = false
                    )
                }
                else -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = "Unknown error",
                        isLoggedIn = false
                    )
                }
            }
        }
    }
    
    fun register(email: String, password: String, displayName: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            val result = registerUseCase(email, password, displayName)
            
            when (result) {
                is Resource.Success -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        isLoggedIn = true,
                        userId = result.data?.uid,
                        error = null
                    )
                }
                is Resource.Error -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = result.message,
                        isLoggedIn = false
                    )
                }
                else -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = "Unknown error",
                        isLoggedIn = false
                    )
                }
            }
        }
    }
    
    fun logout() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            val result = logoutUseCase()
            
            when (result) {
                is Resource.Success -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        isLoggedIn = false,
                        userId = null,
                        error = null
                    )
                }
                is Resource.Error -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = result.message
                    )
                }
                else -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = "Unknown error"
                    )
                }
            }
        }
    }
    
    fun checkCurrentUser() {
        viewModelScope.launch {
            val result = getCurrentUserUseCase()
            _state.value = _state.value.copy(
                isLoggedIn = result.data != null,
                userId = result.data?.id
            )
        }
    }
}

data class AuthState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val userId: String? = null,
    val error: String? = null
)
