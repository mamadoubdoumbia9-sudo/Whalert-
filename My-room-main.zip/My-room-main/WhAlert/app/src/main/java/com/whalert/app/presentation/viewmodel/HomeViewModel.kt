package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whalert.app.data.repository.ReportRepository
import com.whalert.app.data.repository.UserRepository
import com.whalert.app.domain.usecase.auth.GetCurrentUserUseCase
import com.whalert.app.domain.usecase.report.GetAllReportsUseCase
import com.whalert.app.util.NetworkMonitor
import com.whalert.app.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class HomeViewModel(
    private val getCurrentUserUseCase: GetCurrentUserUseCase,
    private val getAllReportsUseCase: GetAllReportsUseCase,
    networkMonitor: NetworkMonitor
) : ViewModel() {
    
    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()
    
    init {
        loadData()
        
        viewModelScope.launch {
            networkMonitor.connectivityFlow().collectLatest { isConnected ->
                _state.value = _state.value.copy(
                    connectionStatus = if (isConnected) "Connected" else "Not Connected"
                )
            }
        }
    }
    
    private fun loadData() {
        viewModelScope.launch {
            // Load current user
            val userResult = getCurrentUserUseCase()
            if (userResult.data != null) {
                _state.value = _state.value.copy(
                    isLoggedIn = true,
                    userId = userResult.data.id
                )
            }
            
            // Load reports
            getAllReportsUseCase().collectLatest { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _state.value = _state.value.copy(
                            totalReports = resource.data?.size ?: 0,
                            statsVisible = true
                        )
                    }
                    else -> {
                        _state.value = _state.value.copy(
                            totalReports = 0,
                            statsVisible = false
                        )
                    }
                }
            }
        }
    }
    
    fun refresh() {
        loadData()
    }
}

data class HomeState(
    val isLoggedIn: Boolean = false,
    val userId: String = "",
    val connectionStatus: String = "Checking...",
    val totalReports: Int = 0,
    val dailyLimit: Int = 3,
    val remainingReports: Int = 3,
    val statsVisible: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null
)
