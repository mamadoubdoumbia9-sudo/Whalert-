package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.usecase.report.GetAllReportsUseCase
import com.whalert.app.domain.usecase.report.DeleteReportUseCase
import com.whalert.app.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ReportHistoryViewModel(
    private val getAllReportsUseCase: GetAllReportsUseCase,
    private val deleteReportUseCase: DeleteReportUseCase
) : ViewModel() {
    
    private val _state = MutableStateFlow(ReportHistoryState())
    val state: StateFlow<ReportHistoryState> = _state.asStateFlow()
    
    init {
        loadReports()
    }
    
    fun loadReports() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            getAllReportsUseCase().collectLatest { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _state.value = _state.value.copy(
                            isLoading = false,
                            reports = resource.data ?: emptyList(),
                            error = null
                        )
                    }
                    is Resource.Error -> {
                        _state.value = _state.value.copy(
                            isLoading = false,
                            error = resource.message
                        )
                    }
                    else -> {
                        _state.value = _state.value.copy(
                            isLoading = false,
                            error = "Unknown error"
                        )
                    }
                }
            }
        }
    }
    
    fun deleteReport(reportId: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            val result = deleteReportUseCase(reportId)
            
            when (result) {
                is Resource.Success -> {
                    loadReports() // Refresh the list
                }
                is Resource.Error -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = result.message
                    )
                }
                else -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = "Unknown error"
                    )
                }
            }
        }
    }
    
    fun filterReports(query: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                searchQuery = query,
                filteredReports = if (query.isBlank()) {
                    _state.value.reports
                } else {
                    _state.value.reports.filter { report ->
                        report.phoneNumber.contains(query, ignoreCase = true) ||
                        report.description.contains(query, ignoreCase = true) ||
                        report.category.getDisplayName().contains(query, ignoreCase = true)
                    }
                }
            )
        }
    }
}

data class ReportHistoryState(
    val isLoading: Boolean = false,
    val reports: List<Report> = emptyList(),
    val filteredReports: List<Report> = emptyList(),
    val searchQuery: String = "",
    val error: String? = null
)
