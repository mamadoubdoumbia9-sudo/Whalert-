package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whalert.app.data.repository.ReportRepository
import com.whalert.app.data.repository.UserRepository
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.usecase.report.CanSubmitReportUseCase
import com.whalert.app.domain.usecase.report.CreateReportUseCase
import com.whalert.app.domain.usecase.report.GetDailyReportCountUseCase
import com.whalert.app.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Date

class ReportViewModel(
    private val createReportUseCase: CreateReportUseCase,
    private val getDailyReportCountUseCase: GetDailyReportCountUseCase,
    private val canSubmitReportUseCase: CanSubmitReportUseCase,
    private val reportRepository: ReportRepository,
    private val userRepository: UserRepository
) : ViewModel() {
    
    private val _state = MutableStateFlow(ReportState())
    val state: StateFlow<ReportState> = _state.asStateFlow()
    
    fun createReport(
        userId: String,
        phoneNumber: String,
        countryCode: String,
        category: ReportCategory,
        description: String,
        date: Date?,
        time: String?,
        evidenceText: List<String>?,
        evidenceImagePaths: List<String>?
    ) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            
            val result = createReportUseCase(
                userId = userId,
                phoneNumber = phoneNumber,
                countryCode = countryCode,
                category = category,
                description = description,
                date = date,
                time = time,
                evidenceText = evidenceText,
                evidenceImagePaths = evidenceImagePaths
            )
            
            when (result) {
                is Resource.Success -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        reportCreated = result.data?.id,
                        error = null
                    )
                }
                is Resource.Error -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = result.message,
                        reportCreated = null
                    )
                }
                else -> {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = "Unknown error",
                        reportCreated = null
                    )
                }
            }
        }
    }
    
    fun checkDailyLimit(userId: String) {
        viewModelScope.launch {
            val result = getDailyReportCountUseCase(userId)
            when (result) {
                is Resource.Success -> {
                    val count = result.data ?: 0
                    val canSubmit = canSubmitReportUseCase(userId).data ?: false
                    _state.value = _state.value.copy(
                        dailyReportCount = count,
                        canSubmitMore = canSubmit
                    )
                }
                else -> {
                    _state.value = _state.value.copy(
                        error = result.message
                    )
                }
            }
        }
    }
    
    fun resetReportCreated() {
        _state.value = _state.value.copy(reportCreated = null)
    }
}

data class ReportState(
    val isLoading: Boolean = false,
    val reportCreated: String? = null,
    val dailyReportCount: Int = 0,
    val canSubmitMore: Boolean = true,
    val error: String? = null
)
