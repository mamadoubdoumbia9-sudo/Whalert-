package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel

class SafetyGuideViewModel : ViewModel() {
    
    fun getGuideSections(): List<GuideSection> {
        return listOf(
            GuideSection(
                title = "Recognize Scams",
                description = "Scammers often pretend to be someone you know or trust. They may ask for money, personal information, or access to your accounts.",
                iconRes = "ic_scams",
                tips = listOf(
                    "Be skeptical of urgent requests for money",
                    "Verify the identity of the person contacting you",
                    "Never share your passwords or verification codes",
                    "Check for unusual payment methods or requests"
                )
            ),
            GuideSection(
                title = "Fraudulent Accounts",
                description = "Look for signs like unusual profile pictures, inconsistent information, or requests that seem out of character.",
                iconRes = "ic_impersonation",
                tips = listOf(
                    "Check the profile picture and display name",
                    "Look for verified badges on business accounts",
                    "Be cautious of newly created accounts",
                    "Verify through other communication channels"
                )
            ),
            GuideSection(
                title = "Preserve Evidence",
                description = "Take screenshots of conversations, save messages, and note dates and times of suspicious activities.",
                iconRes = "ic_camera",
                tips = listOf(
                    "Take screenshots of the conversation",
                    "Save the contact information",
                    "Note the date and time of the incident",
                    "Keep a record of any transactions or requests"
                )
            ),
            GuideSection(
                title = "Do Not Threaten",
                description = "Never threaten or harass the person you are reporting. Stick to factual information only.",
                iconRes = "ic_no_threats",
                tips = listOf(
                    "Report only based on facts",
                    "Avoid emotional language",
                    "Don't engage in arguments",
                    "Focus on the behavior, not the person"
                )
            ),
            GuideSection(
                title = "No False Reports",
                description = "Only report accounts that you genuinely believe are involved in malicious activities. False reports waste resources.",
                iconRes = "ic_no_false_reports",
                tips = listOf(
                    "Report only real incidents",
                    "Don't report out of personal vendettas",
                    "Ensure you have sufficient evidence",
                    "Be honest and accurate in your report"
                )
            ),
            GuideSection(
                title = "Use Official Channels",
                description = "Always use WhatsApp's official reporting mechanisms. This app helps you prepare and organize your reports.",
                iconRes = "ic_official",
                tips = listOf(
                    "Use the official WhatsApp reporting feature",
                    "Follow WhatsApp's reporting guidelines",
                    "Provide as much detail as possible",
                    "Be patient - investigations take time"
                )
            ),
            GuideSection(
                title = "Protect Your Information",
                description = "Never share your personal information, passwords, or sensitive data with anyone, including through this app.",
                iconRes = "ic_security",
                tips = listOf(
                    "Never share your password",
                    "Don't share verification codes",
                    "Be cautious with personal information",
                    "Use strong, unique passwords"
                )
            )
        )
    }
}

data class GuideSection(
    val title: String,
    val description: String,
    val iconRes: String,
    val tips: List<String>
)
