package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whalert.app.data.local.UserPreferencesRepository
import com.whalert.app.domain.usecase.auth.LogoutUseCase
import com.whalert.app.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {
    
    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()
    
    init {
        loadPreferences()
    }
    
    fun loadPreferences() {
        viewModelScope.launch {
            userPreferencesRepository.themeFlow.collectLatest { theme ->
                _state.value = _state.value.copy(theme = theme)
            }
            
            userPreferencesRepository.notificationsEnabledFlow.collectLatest { enabled ->
                _state.value = _state.value.copy(notificationsEnabled = enabled)
            }
            
            userPreferencesRepository.notificationsSoundFlow.collectLatest { enabled ->
                _state.value = _state.value.copy(notificationsSound = enabled)
            }
            
            userPreferencesRepository.notificationsVibrateFlow.collectLatest { enabled ->
                _state.value = _state.value.copy(notificationsVibrate = enabled)
            }
            
            userPreferencesRepository.biometricEnabledFlow.collectLatest { enabled ->
                _state.value = _state.value.copy(biometricEnabled = enabled)
            }
            
            userPreferencesRepository.dailyLimitFlow.collectLatest { limit ->
                _state.value = _state.value.copy(dailyLimit = limit)
            }
        }
    }
    
    fun setTheme(theme: String) {
        viewModelScope.launch {
            userPreferencesRepository.setTheme(theme)
            _state.value = _state.value.copy(theme = theme)
        }
    }
    
    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setNotificationsEnabled(enabled)
            _state.value = _state.value.copy(notificationsEnabled = enabled)
        }
    }
    
    fun setNotificationsSound(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setNotificationsSound(enabled)
            _state.value = _state.value.copy(notificationsSound = enabled)
        }
    }
    
    fun setNotificationsVibrate(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setNotificationsVibrate(enabled)
            _state.value = _state.value.copy(notificationsVibrate = enabled)
        }
    }
    
    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setBiometricEnabled(enabled)
            _state.value = _state.value.copy(biometricEnabled = enabled)
        }
    }
    
    fun setDailyLimit(limit: String) {
        viewModelScope.launch {
            userPreferencesRepository.setDailyLimit(limit)
            _state.value = _state.value.copy(dailyLimit = limit)
        }
    }
}

data class SettingsState(
    val theme: String = "system",
    val notificationsEnabled: Boolean = true,
    val notificationsSound: Boolean = true,
    val notificationsVibrate: Boolean = true,
    val biometricEnabled: Boolean = false,
    val dailyLimit: String = "3",
    val isLoading: Boolean = false,
    val error: String? = null
)
