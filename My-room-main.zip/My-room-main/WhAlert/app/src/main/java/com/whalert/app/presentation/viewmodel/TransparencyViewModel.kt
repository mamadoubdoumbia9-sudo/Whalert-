package com.whalert.app.presentation.viewmodel

import androidx.lifecycle.ViewModel

class TransparencyViewModel : ViewModel() {
    
    // This ViewModel doesn't need any state management
    // as the transparency screen is static content
    
    fun getCanDoItems(): List<Pair<String, String>> {
        return listOf(
            "Prepare a report dossier" to "Organize all information and evidence for your report",
            "Organize evidence" to "Keep track of screenshots, messages, and other proof",
            "Generate report text" to "Create a professional, fact-based report text",
            "Request confirmation" to "Ask for your explicit confirmation before submission",
            "Transmit via available channels" to "Use official WhatsApp reporting mechanisms",
            "Store your report history" to "Keep a record of all your submitted reports",
            "Show technical confirmations" to "Display confirmations received from official channels"
        )
    }
    
    fun getCannotDoItems(): List<Pair<String, String>> {
        return listOf(
            "Guarantee account suspension" to "Only WhatsApp can decide to suspend an account",
            "Know WhatsApp's internal decisions" to "WhatsApp does not provide public confirmation of moderation decisions",
            "Send false reports" to "All reports must be genuine and based on real experiences",
            "Multiply reports artificially" to "Each report must correspond to a real incident",
            "Bypass WhatsApp protections" to "This app respects all of WhatsApp's security measures",
            "Force WhatsApp to suspend an account" to "Suspension decisions are made solely by WhatsApp"
        )
    }
}
