package com.whalert.app.util

object Constants {
    // App
    const val APP_NAME = "WhAlert"
    const val APP_PACKAGE = "com.whalert.app"
    const val APP_VERSION = "1.0.0"
    const val APP_VERSION_CODE = 1
    
    // Database
    const val DATABASE_NAME = "whalert_database"
    
    // Preferences
    const val PREF_THEME = "pref_theme"
    const val PREF_LANGUAGE = "pref_language"
    const val PREF_NOTIFICATIONS_ENABLED = "pref_notifications_enabled"
    const val PREF_NOTIFICATIONS_SOUND = "pref_notifications_sound"
    const val PREF_NOTIFICATIONS_VIBRATE = "pref_notifications_vibrate"
    const val PREF_BIOMETRIC_ENABLED = "pref_biometric_enabled"
    const val PREF_DAILY_LIMIT = "pref_daily_limit"
    const val PREF_FIRST_LAUNCH = "pref_first_launch"
    const val PREF_ONBOARDING_COMPLETED = "pref_onboarding_completed"
    
    // Theme
    const val THEME_SYSTEM = "system"
    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"
    
    // Language
    const val LANGUAGE_SYSTEM = "system"
    const val LANGUAGE_ENGLISH = "en"
    const val LANGUAGE_FRENCH = "fr"
    
    // Network
    const val BASE_URL = "https://api.whalert.app/v1/"
    const val CONNECTION_TIMEOUT = 30000L
    const val READ_TIMEOUT = 30000L
    const val WRITE_TIMEOUT = 30000L
    
    // Validation
    const val MIN_PASSWORD_LENGTH = 8
    const val MAX_DESCRIPTION_LENGTH = 2000
    const val MAX_EVIDENCE_ITEMS = 10
    const val MAX_EVIDENCE_SIZE = 10 * 1024 * 1024 // 10MB
    
    // Reports
    const val DEFAULT_DAILY_LIMIT = 3
    const val REPORT_ID_LENGTH = 36 // UUID length
    
    // WhatsApp
    const val WHATSAPP_HELP_CENTER = "https://help.whatsapp.com"
    const val WHATSAPP_REPORT_GUIDE = "https://faq.whatsapp.com/general/security-and-privacy/report-a-contact"
    const val WHATSAPP_TERMS = "https://www.whatsapp.com/legal/terms-of-service"
    const val WHATSAPP_PRIVACY = "https://www.whatsapp.com/legal/privacy-policy"
    
    // Email
    const val EMAIL_SIGNATURE = "\n\n---\nThis report was created using WhAlert.\nFor more information, visit https://whalert.app"
    const val EMAIL_SUBJECT_PREFIX = "WhatsApp Report: "
    
    // Storage
    const val STORAGE_DIR_REPORTS = "reports"
    const val STORAGE_DIR_EVIDENCE = "evidence"
    const val STORAGE_DIR_LOGS = "logs"
    
    // Security
    const val BIOMETRIC_KEY_ALIAS = "whalert_biometric_key"
    const val ENCRYPTION_KEY_ALIAS = "whalert_encryption_key"
    
    // Firebase
    const val FIREBASE_COLLECTION_USERS = "users"
    const val FIREBASE_COLLECTION_REPORTS = "reports"
    const val FIREBASE_COLLECTION_LOGS = "logs"
    const val FIREBASE_STORAGE_EVIDENCE = "evidence"
    
    // Admin
    const val ADMIN_CONSOLE_PATH = "/admin"
    const val ADMIN_AUTH_TOKEN = "admin_auth_token"
    
    // Status Messages
    const val STATUS_DRAFT = "Draft"
    const val STATUS_PREPARED = "Prepared"
    const val STATUS_SUBMITTED = "Submitted"
    const val STATUS_CONFIRMATION_RECEIVED = "Confirmation Received"
    const val STATUS_FOLLOW_UP_NEEDED = "Follow-up Needed"
    const val STATUS_CLOSED = "Closed"
    
    // Error Messages
    const val ERROR_NETWORK_UNAVAILABLE = "Network unavailable"
    const val ERROR_INVALID_PHONE = "Invalid phone number"
    const val ERROR_INVALID_EMAIL = "Invalid email address"
    const val ERROR_WEAK_PASSWORD = "Password must be at least 8 characters"
    const val ERROR_PASSWORD_MISMATCH = "Passwords do not match"
    const val ERROR_USER_NOT_FOUND = "User not found"
    const val ERROR_REPORT_NOT_FOUND = "Report not found"
    const val ERROR_LIMIT_REACHED = "Daily limit reached"
    const val ERROR_PERMISSION_DENIED = "Permission denied"
    const val ERROR_STORAGE_FULL = "Storage full"
    const val ERROR_UNKNOWN = "An unknown error occurred"
}
