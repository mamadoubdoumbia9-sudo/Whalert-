package com.whalert.app.util

import com.google.i18n.phonenumbers.NumberParseException
import com.google.i18n.phonenumbers.PhoneNumberUtil
import java.util.Locale

/**
 * Utility class for validating phone numbers using libphonenumber
 */
class PhoneNumberValidator {
    
    private val phoneUtil: PhoneNumberUtil = PhoneNumberUtil.getInstance()
    
    /**
     * Validate a phone number in E.164 format
     */
    fun isValidE164(phoneNumber: String): Boolean {
        try {
            val parsed = phoneUtil.parse(phoneNumber, null)
            return phoneUtil.isValidNumber(parsed)
        } catch (e: NumberParseException) {
            return false
        }
    }
    
    /**
     * Validate a phone number with country code
     */
    fun isValidWithCountryCode(phoneNumber: String, countryCode: String): Boolean {
        try {
            val parsed = phoneUtil.parse(phoneNumber, countryCode)
            return phoneUtil.isValidNumber(parsed)
        } catch (e: NumberParseException) {
            return false
        }
    }
    
    /**
     * Format a phone number to E.164 format
     */
    fun formatToE164(phoneNumber: String, countryCode: String): String? {
        try {
            val parsed = phoneUtil.parse(phoneNumber, countryCode)
            return phoneUtil.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164)
        } catch (e: NumberParseException) {
            return null
        }
    }
    
    /**
     * Format a phone number for display
     */
    fun formatForDisplay(phoneNumber: String, countryCode: String): String? {
        try {
            val parsed = phoneUtil.parse(phoneNumber, countryCode)
            return phoneUtil.format(parsed, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL)
        } catch (e: NumberParseException) {
            return null
        }
    }
    
    /**
     * Extract country code from a phone number
     */
    fun extractCountryCode(phoneNumber: String): String? {
        try {
            val parsed = phoneUtil.parse(phoneNumber, null)
            return "+${parsed.countryCode}"
        } catch (e: NumberParseException) {
            return null
        }
    }
    
    /**
     * Get the national number (without country code)
     */
    fun getNationalNumber(phoneNumber: String): String? {
        try {
            val parsed = phoneUtil.parse(phoneNumber, null)
            return parsed.nationalNumber.toString()
        } catch (e: NumberParseException) {
            return null
        }
    }
    
    /**
     * Validate and format a phone number
     * Returns a pair of (isValid, formattedNumber)
     */
    fun validateAndFormat(phoneNumber: String, countryCode: String): Pair<Boolean, String?> {
        val isValid = isValidWithCountryCode(phoneNumber, countryCode)
        val formatted = if (isValid) formatToE164(phoneNumber, countryCode) else null
        return Pair(isValid, formatted)
    }
    
    /**
     * Get all country calling codes
     */
    fun getCountryCallingCodes(): List<String> {
        val regions = Locale.getISOCountries()
        return regions.mapNotNull { region ->
            try {
                val countryCode = phoneUtil.getCountryCodeForRegion(region)
                if (countryCode != 0) "+$countryCode" else null
            } catch (e: Exception) {
                null
            }
        }.distinct().sorted()
    }
    
    /**
     * Get country code for current locale
     */
    fun getCurrentCountryCode(): String {
        val locale = Locale.getDefault()
        val countryCode = locale.country
        return try {
            val code = phoneUtil.getCountryCodeForRegion(countryCode)
            if (code != 0) "+$code" else "+1" // Default to US if not found
        } catch (e: Exception) {
            "+1" // Default to US
        }
    }
}
