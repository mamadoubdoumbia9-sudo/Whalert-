package com.whalert.app.util

/**
 * A generic class to represent the state of a resource
 */
sealed class Resource<T>(val data: T? = null, val message: String? = null) {
    class Success<T>(data: T) : Resource<T>(data)
    class Error<T>(message: String, data: T? = null) : Resource<T>(data, message)
    class Loading<T> : Resource<T>()
    
    companion object {
        fun <T> success(data: T): Resource<T> = Success(data)
        fun <T> error(message: String, data: T? = null): Resource<T> = Error(message, data)
        fun <T> loading(): Resource<T> = Loading()
    }
}

/**
 * A sealed class for network operations
 */
sealed class NetworkResource<T>(val data: T? = null, val message: String? = null, val code: Int? = null) {
    class Success<T>(data: T, code: Int? = null) : NetworkResource<T>(data, null, code)
    class Error<T>(message: String, code: Int? = null, data: T? = null) : NetworkResource<T>(data, message, code)
    class Loading<T> : NetworkResource<T>()
    
    companion object {
        fun <T> success(data: T, code: Int? = null): NetworkResource<T> = Success(data, code)
        fun <T> error(message: String, code: Int? = null, data: T? = null): NetworkResource<T> = Error(message, code, data)
        fun <T> loading(): NetworkResource<T> = Loading()
    }
}

/**
 * A sealed class for validation results
 */
sealed class ValidationResult {
    object Valid : ValidationResult()
    data class Invalid(val message: String) : ValidationResult()
    
    fun isValid(): Boolean = this is Valid
    fun getErrorMessage(): String? = (this as? Invalid)?.message
}
