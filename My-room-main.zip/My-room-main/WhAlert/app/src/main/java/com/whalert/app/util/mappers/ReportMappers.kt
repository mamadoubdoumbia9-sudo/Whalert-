package com.whalert.app.util.mappers

import com.whalert.app.data.local.entity.ReportEntity
import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.model.ReportStatus

/**
 * Extension functions to map between ReportEntity and Report domain model
 */

fun ReportEntity.toDomain(): Report {
    return Report(
        id = id,
        userId = userId,
        phoneNumber = phoneNumber,
        countryCode = countryCode,
        category = category,
        description = description,
        date = date,
        time = time,
        evidenceText = evidenceText,
        evidenceImagePaths = null, // Will be mapped from evidenceImages if needed
        status = status,
        createdAt = createdAt,
        updatedAt = updatedAt,
        submittedAt = submittedAt,
        confirmationReceived = confirmationReceived,
        confirmationDetails = confirmationDetails,
        officialDecision = officialDecision
    )
}

fun Report.toEntity(): ReportEntity {
    return ReportEntity(
        id = id,
        userId = userId,
        phoneNumber = phoneNumber,
        countryCode = countryCode,
        category = category,
        description = description,
        date = date,
        time = time,
        evidenceText = evidenceText,
        evidenceImages = null, // Will be mapped from evidenceImagePaths if needed
        status = status,
        createdAt = createdAt,
        updatedAt = updatedAt,
        submittedAt = submittedAt,
        confirmationReceived = confirmationReceived,
        confirmationDetails = confirmationDetails,
        officialDecision = officialDecision
    )
}

/**
 * Mapper for ReportCategory
 */
fun String.toReportCategory(): ReportCategory {
    return try {
        ReportCategory.valueOf(this.uppercase())
    } catch (e: IllegalArgumentException) {
        ReportCategory.OTHER
    }
}

fun ReportCategory.toStringValue(): String {
    return this.name.lowercase()
}

/**
 * Mapper for ReportStatus
 */
fun String.toReportStatus(): ReportStatus {
    return try {
        ReportStatus.valueOf(this.uppercase())
    } catch (e: IllegalArgumentException) {
        ReportStatus.DRAFT
    }
}

fun ReportStatus.toStringValue(): String {
    return this.name.lowercase()
}
