package com.whalert.app.util.mappers

import com.google.firebase.auth.FirebaseUser
import com.whalert.app.data.local.entity.UserEntity
import com.whalert.app.domain.model.User

/**
 * Extension functions to map between UserEntity and User domain model
 */

fun UserEntity.toDomain(): User {
    return User(
        id = id,
        email = email,
        displayName = displayName,
        phoneNumber = phoneNumber,
        avatarUrl = avatarUrl,
        isAdmin = isAdmin,
        isEmailVerified = isEmailVerified,
        dailyReportLimit = dailyReportLimit,
        lastReportDate = lastReportDate,
        reportCountToday = reportCountToday,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun User.toEntity(): UserEntity {
    return UserEntity(
        id = id,
        email = email,
        displayName = displayName,
        phoneNumber = phoneNumber,
        avatarUrl = avatarUrl,
        isAdmin = isAdmin,
        isEmailVerified = isEmailVerified,
        dailyReportLimit = dailyReportLimit,
        lastReportDate = lastReportDate,
        reportCountToday = reportCountToday,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

/**
 * Mapper from FirebaseUser to User domain model
 */
fun FirebaseUser.toDomain(): User {
    return User(
        id = uid,
        email = email ?: "",
        displayName = displayName,
        phoneNumber = phoneNumber,
        avatarUrl = photoUrl?.toString(),
        isAdmin = false, // Firebase doesn't have admin info
        isEmailVerified = isEmailVerified,
        dailyReportLimit = 3, // Default limit
        lastReportDate = null,
        reportCountToday = 0,
        createdAt = java.util.Date(),
        updatedAt = java.util.Date()
    )
}
