package com.whalert.app

import com.whalert.app.util.PhoneNumberValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class PhoneNumberValidatorTest {
    
    private lateinit var validator: PhoneNumberValidator
    
    @Before
    fun setup() {
        validator = PhoneNumberValidator()
    }
    
    @Test
    fun testIsValidE164_ValidNumbers() {
        // Test valid E.164 numbers
        assertTrue(validator.isValidE164("+14155552671"))
        assertTrue(validator.isValidE164("+442079460000"))
        assertTrue(validator.isValidE164("+33145556789"))
        assertTrue(validator.isValidE164("+22312345678"))
    }
    
    @Test
    fun testIsValidE164_InvalidNumbers() {
        // Test invalid E.164 numbers
        assertFalse(validator.isValidE164("14155552671")) // Missing country code
        assertFalse(validator.isValidE164("+12345678901234567890")) // Too long
        assertFalse(validator.isValidE164("+1")) // Too short
        assertFalse(validator.isValidE164("")) // Empty
        assertFalse(validator.isValidE164("invalid")) // Not a number
    }
    
    @Test
    fun testIsValidWithCountryCode_Valid() {
        // Test valid numbers with country code
        assertTrue(validator.isValidWithCountryCode("4155552671", "US"))
        assertTrue(validator.isValidWithCountryCode("2079460000", "GB"))
        assertTrue(validator.isValidWithCountryCode("145556789", "FR"))
    }
    
    @Test
    fun testIsValidWithCountryCode_Invalid() {
        // Test invalid numbers with country code
        assertFalse(validator.isValidWithCountryCode("123", "US"))
        assertFalse(validator.isValidWithCountryCode("12345678901234567890", "US"))
    }
    
    @Test
    fun testFormatToE164() {
        // Test formatting to E.164
        val formatted = validator.formatToE164("4155552671", "US")
        assertNotNull(formatted)
        assertEquals("+14155552671", formatted)
    }
    
    @Test
    fun testFormatToE164_Invalid() {
        // Test formatting invalid number
        val formatted = validator.formatToE164("123", "US")
        assertTrue(formatted.isNullOrEmpty())
    }
    
    @Test
    fun testFormatForDisplay() {
        // Test formatting for display
        val formatted = validator.formatForDisplay("4155552671", "US")
        assertNotNull(formatted)
        assertTrue(formatted.contains("1"))
        assertTrue(formatted.contains("415"))
        assertTrue(formatted.contains("555"))
    }
    
    @Test
    fun testExtractCountryCode() {
        // Test extracting country code
        val countryCode = validator.extractCountryCode("+14155552671")
        assertEquals("+1", countryCode)
        
        val countryCode2 = validator.extractCountryCode("+442079460000")
        assertEquals("+44", countryCode2)
    }
    
    @Test
    fun testGetNationalNumber() {
        // Test getting national number
        val nationalNumber = validator.getNationalNumber("+14155552671")
        assertEquals("4155552671", nationalNumber)
    }
    
    @Test
    fun testValidateAndFormat_Valid() {
        // Test validate and format with valid number
        val (isValid, formatted) = validator.validateAndFormat("4155552671", "US")
        assertTrue(isValid)
        assertEquals("+14155552671", formatted)
    }
    
    @Test
    fun testValidateAndFormat_Invalid() {
        // Test validate and format with invalid number
        val (isValid, formatted) = validator.validateAndFormat("123", "US")
        assertFalse(isValid)
        assertTrue(formatted.isNullOrEmpty())
    }
    
    @Test
    fun testGetCurrentCountryCode() {
        // Test getting current country code
        val countryCode = validator.getCurrentCountryCode()
        assertNotNull(countryCode)
        assertTrue(countryCode.startsWith("+"))
    }
    
    @Test
    fun testGetCountryCallingCodes() {
        // Test getting all country calling codes
        val codes = validator.getCountryCallingCodes()
        assertNotNull(codes)
        assertTrue(codes.isNotEmpty())
        assertTrue(codes.all { it.startsWith("+") })
    }
}
