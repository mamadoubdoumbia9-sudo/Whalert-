package com.whalert.app

import com.whalert.app.domain.model.Report
import com.whalert.app.domain.model.ReportCategory
import com.whalert.app.domain.model.ReportStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Date

class ReportModelTest {
    
    @Test
    fun testGetFullPhoneNumber() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description"
        )
        
        assertEquals("+11234567890", report.getFullPhoneNumber())
    }
    
    @Test
    fun testGetFormattedDate() {
        val date = Date(122, 0, 1) // January 1, 2022
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            date = date
        )
        
        val formattedDate = report.getFormattedDate()
        assertNotNull(formattedDate)
        assertTrue(formattedDate.contains("1"))
        assertTrue(formattedDate.contains("1"))
        assertTrue(formattedDate.contains("2022"))
    }
    
    @Test
    fun testGetFormattedDate_Null() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            date = null
        )
        
        assertEquals("N/A", report.getFormattedDate())
    }
    
    @Test
    fun testGetFormattedTime() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            time = "10:30 AM"
        )
        
        assertEquals("10:30 AM", report.getFormattedTime())
    }
    
    @Test
    fun testGetFormattedTime_Null() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            time = null
        )
        
        assertEquals("N/A", report.getFormattedTime())
    }
    
    @Test
    fun testHasEvidence_WithText() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            evidenceText = listOf("Evidence 1", "Evidence 2")
        )
        
        assertTrue(report.hasEvidence())
    }
    
    @Test
    fun testHasEvidence_WithImages() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            evidenceImagePaths = listOf("path1", "path2")
        )
        
        assertTrue(report.hasEvidence())
    }
    
    @Test
    fun testHasEvidence_NoEvidence() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description"
        )
        
        assertFalse(report.hasEvidence())
    }
    
    @Test
    fun testGetEvidenceCount() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            evidenceText = listOf("Evidence 1", "Evidence 2"),
            evidenceImagePaths = listOf("path1", "path2", "path3")
        )
        
        assertEquals(5, report.getEvidenceCount())
    }
    
    @Test
    fun testIsSubmitted_Draft() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            status = ReportStatus.DRAFT
        )
        
        assertFalse(report.isSubmitted())
    }
    
    @Test
    fun testIsSubmitted_Submitted() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            status = ReportStatus.SUBMITTED
        )
        
        assertTrue(report.isSubmitted())
    }
    
    @Test
    fun testIsSubmitted_ConfirmationReceived() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            status = ReportStatus.CONFIRMATION_RECEIVED
        )
        
        assertTrue(report.isSubmitted())
    }
    
    @Test
    fun testIsSubmitted_FollowUpNeeded() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            status = ReportStatus.FOLLOW_UP_NEEDED
        )
        
        assertTrue(report.isSubmitted())
    }
    
    @Test
    fun testIsSubmitted_Closed() {
        val report = Report(
            id = "1",
            userId = "user1",
            phoneNumber = "1234567890",
            countryCode = "+1",
            category = ReportCategory.SPAM,
            description = "Test description",
            status = ReportStatus.CLOSED
        )
        
        assertTrue(report.isSubmitted())
    }
    
    @Test
    fun testReportCategoryDisplayNames() {
        assertEquals("Spam", ReportCategory.SPAM.getDisplayName())
        assertEquals("Scams", ReportCategory.SCAMS.getDisplayName())
        assertEquals("Impersonation", ReportCategory.IMPERSONATION.getDisplayName())
        assertEquals("Harassment", ReportCategory.HARASSMENT.getDisplayName())
        assertEquals("Fraudulent Content", ReportCategory.FRAUDULENT_CONTENT.getDisplayName())
        assertEquals("Malicious Behavior", ReportCategory.MALICIOUS_BEHAVIOR.getDisplayName())
        assertEquals("Other", ReportCategory.OTHER.getDisplayName())
    }
    
    @Test
    fun testReportStatusDisplayNames() {
        assertEquals("Draft", ReportStatus.DRAFT.getDisplayName())
        assertEquals("Prepared", ReportStatus.PREPARED.getDisplayName())
        assertEquals("Submitted", ReportStatus.SUBMITTED.getDisplayName())
        assertEquals("Confirmation Received", ReportStatus.CONFIRMATION_RECEIVED.getDisplayName())
        assertEquals("Follow-up Needed", ReportStatus.FOLLOW_UP_NEEDED.getDisplayName())
        assertEquals("Closed", ReportStatus.CLOSED.getDisplayName())
    }
}
