package com.whalert.app

import com.whalert.app.util.NetworkResource
import com.whalert.app.util.Resource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceTest {
    
    @Test
    fun testResourceSuccess() {
        val data = "test data"
        val resource = Resource.success(data)
        
        assertTrue(resource is Resource.Success)
        assertEquals(data, resource.data)
        assertNull(resource.message)
    }
    
    @Test
    fun testResourceError() {
        val message = "error message"
        val data = "test data"
        val resource = Resource.error(message, data)
        
        assertTrue(resource is Resource.Error)
        assertEquals(data, resource.data)
        assertEquals(message, resource.message)
    }
    
    @Test
    fun testResourceErrorNoData() {
        val message = "error message"
        val resource = Resource.error<Any>(message)
        
        assertTrue(resource is Resource.Error)
        assertNull(resource.data)
        assertEquals(message, resource.message)
    }
    
    @Test
    fun testResourceLoading() {
        val resource = Resource.loading<String>()
        
        assertTrue(resource is Resource.Loading)
        assertNull(resource.data)
        assertNull(resource.message)
    }
    
    @Test
    fun testNetworkResourceSuccess() {
        val data = "test data"
        val code = 200
        val resource = NetworkResource.success(data, code)
        
        assertTrue(resource is NetworkResource.Success)
        assertEquals(data, resource.data)
        assertEquals(code, resource.code)
        assertNull(resource.message)
    }
    
    @Test
    fun testNetworkResourceError() {
        val message = "error message"
        val code = 404
        val data = "test data"
        val resource = NetworkResource.error(message, code, data)
        
        assertTrue(resource is NetworkResource.Error)
        assertEquals(data, resource.data)
        assertEquals(message, resource.message)
        assertEquals(code, resource.code)
    }
    
    @Test
    fun testNetworkResourceErrorNoData() {
        val message = "error message"
        val code = 404
        val resource = NetworkResource.error<Any>(message, code)
        
        assertTrue(resource is NetworkResource.Error)
        assertNull(resource.data)
        assertEquals(message, resource.message)
        assertEquals(code, resource.code)
    }
    
    @Test
    fun testNetworkResourceLoading() {
        val resource = NetworkResource.loading<String>()
        
        assertTrue(resource is NetworkResource.Loading)
        assertNull(resource.data)
        assertNull(resource.message)
        assertNull(resource.code)
    }
}
