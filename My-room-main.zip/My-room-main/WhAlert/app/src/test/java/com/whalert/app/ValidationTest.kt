package com.whalert.app

import com.whalert.app.util.ValidationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidationTest {
    
    @Test
    fun testValidationResultIsValid() {
        val validResult = ValidationResult.Valid
        assertTrue(validResult.isValid())
        assertTrue(validResult.getErrorMessage().isNullOrEmpty())
    }
    
    @Test
    fun testValidationResultInvalid() {
        val errorMessage = "This is an error"
        val invalidResult = ValidationResult.Invalid(errorMessage)
        assertFalse(invalidResult.isValid())
        assertEquals(errorMessage, invalidResult.getErrorMessage())
    }
    
    @Test
    fun testValidationResultInvalidNullMessage() {
        val invalidResult = ValidationResult.Invalid(null)
        assertFalse(invalidResult.isValid())
        assertTrue(invalidResult.getErrorMessage().isNullOrEmpty())
    }
    
    @Test
    fun testEmailValidation() {
        // Valid emails
        assertTrue(isValidEmail("test@example.com"))
        assertTrue(isValidEmail("user.name@example.com"))
        assertTrue(isValidEmail("user+name@example.com"))
        assertTrue(isValidEmail("user@sub.example.com"))
        assertTrue(isValidEmail("user@example.co.uk"))
        
        // Invalid emails
        assertFalse(isValidEmail(""))
        assertFalse(isValidEmail("invalid"))
        assertFalse(isValidEmail("user@"))
        assertFalse(isValidEmail("@example.com"))
        assertFalse(isValidEmail("user example.com"))
    }
    
    @Test
    fun testPasswordValidation() {
        // Valid passwords
        assertTrue(isValidPassword("Password123"))
        assertTrue(isValidPassword("MySecurePass1"))
        assertTrue(isValidPassword("Another@Password1"))
        
        // Invalid passwords
        assertFalse(isValidPassword(""))
        assertFalse(isValidPassword("short"))
        assertFalse(isValidPassword("nouppercase1"))
        assertFalse(isValidPassword("NOLOWERCASE1"))
        assertFalse(isValidPassword("NoDigitsHere"))
    }
    
    @Test
    fun testDescriptionValidation() {
        // Valid descriptions
        assertTrue(isValidDescription("This is a valid description with more than 10 characters"))
        assertTrue(isValidDescription("Valid"))
        
        // Invalid descriptions
        assertFalse(isValidDescription(""))
        assertFalse(isValidDescription("Short")) // Less than 10 characters
    }
    
    private fun isValidEmail(email: String): Boolean {
        if (email.isBlank()) return false
        val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\$[A-Za-z]{2,}\"")
        return emailRegex.matches(email)
    }
    
    private fun isValidPassword(password: String): Boolean {
        if (password.isBlank()) return false
        if (password.length < 8) return false
        if (!password.any { it.isUpperCase() }) return false
        if (!password.any { it.isLowerCase() }) return false
        if (!password.any { it.isDigit() }) return false
        return true
    }
    
    private fun isValidDescription(description: String): Boolean {
        if (description.isBlank()) return false
        if (description.length < 10) return false
        return true
    }
}
